"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

var Processor = require('/lib/tencent').Processor;

var PROC_TYPE_ALL = require('/lib/tencent').PROC_TYPE_ALL;
/**
 * 函数切片
 */


var FunctionProc =
/*#__PURE__*/
function () {
  function FunctionProc() {
    var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

    _classCallCheck(this, FunctionProc);

    this._options = options;
    this._processors = [];
  }

  _createClass(FunctionProc, [{
    key: "run",
    value: function () {
      var _run = _asyncToGenerator(
      /*#__PURE__*/
      regeneratorRuntime.mark(function _callee(options) {
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return this._execProc(options);

              case 2:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function run(_x) {
        return _run.apply(this, arguments);
      }

      return run;
    }()
  }, {
    key: "addProc",
    value: function addProc(fn) {
      var _this = this;

      var desc = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'Processor';

      if (Array.isArray(fn)) {
        fn.forEach(function (p) {
          return _this.addProc(p);
        });
        return this;
      }

      if (fn instanceof Processor) {
        this._processors.push(fn);

        return this;
      }

      this._processors.push(new Processor(fn, desc, PROC_TYPE_ALL));

      return this;
    }
  }, {
    key: "_execProc",
    value: function () {
      var _execProc2 = _asyncToGenerator(
      /*#__PURE__*/
      regeneratorRuntime.mark(function _callee2(options) {
        var processors, result, i, len, processor;
        return regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                processors = this._processors.filter(function (_ref) {
                  var scope = _ref.scope;
                  return scope === PROC_TYPE_ALL;
                });

                if (processors.length) {
                  _context2.next = 3;
                  break;
                }

                return _context2.abrupt("return", options);

              case 3:
                result = options;
                i = 0, len = processors.length;

              case 5:
                if (!(i < len)) {
                  _context2.next = 25;
                  break;
                }

                processor = processors[i];
                _context2.prev = 7;
                console.log("---Processor\u6267\u884C---".concat(processor.desc));
                _context2.next = 11;
                return processor.run(options, result, this._context);

              case 11:
                _context2.t0 = _context2.sent;

                if (_context2.t0) {
                  _context2.next = 14;
                  break;
                }

                _context2.t0 = result;

              case 14:
                result = _context2.t0;
                console.log("---Processor\u6267\u884C\u5B8C\u6210---".concat(processor.desc));
                _context2.next = 22;
                break;

              case 18:
                _context2.prev = 18;
                _context2.t1 = _context2["catch"](7);
                console.log("---".concat(this.constructor.name, "._execProc---error when exec processor.(").concat(_context2.t1.message, ")"));
                throw _context2.t1;

              case 22:
                i++;
                _context2.next = 5;
                break;

              case 25:
                return _context2.abrupt("return", result);

              case 26:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this, [[7, 18]]);
      }));

      function _execProc(_x2) {
        return _execProc2.apply(this, arguments);
      }

      return _execProc;
    }()
  }]);

  return FunctionProc;
}();

exports.default = FunctionProc;