"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.invoke = invoke;
exports.on = on;
exports.off = off;

var _util = require("./util");

var debounce = require('/lib/lodash-es').debounce;
/**
 * 调用客户端 api
 * @param {String} api
 * @param {Object} [params=null] 参数
 * @param {Boolean} [{ timeout = 5000 }={}] timeout 超时时长设置
 * @returns {Promise}
 */


function invoke(api) {
  var params = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;

  var _ref = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {},
      _ref$timeout = _ref.timeout,
      timeout = _ref$timeout === void 0 ? -1 : _ref$timeout,
      _ref$notNeedLog = _ref.notNeedLog,
      notNeedLog = _ref$notNeedLog === void 0 ? false : _ref$notNeedLog;

  if (!notNeedLog) {
    console.log("[atom] invoke api=".concat(api, " params=") + JSON.stringify(params));
  }

  var finish = false;
  return new Promise(function (resolve, reject) {
    if (timeout > 0) {
      setTimeout(function () {
        if (!finish) {
          console.log("[atom] invoke api=".concat(api, " timeOut"));
          reject(new Error("[atom] invoke api=".concat(api, " timeOut")));
        }
      }, timeout);
    }

    if (typeof TenvideoJSBridge['invoke'] !== 'function') {
      return reject(new Error('TenvideoJSBridge 找不到方法 "invoke"'));
    }

    var callbackResult = TenvideoJSBridge['invoke'](api, params, function (jsonMsg) {
      console.log("[atom] invoke callback api=".concat(api, " response=").concat(JSON.stringify(jsonMsg)));
      console.log("---isPlainObject:".concat((0, _util.isPlainObject)(jsonMsg), "---"));

      if (!(0, _util.isPlainObject)(jsonMsg)) {
        var res = null;

        try {
          res = JSON.parse(jsonMsg);
        } catch (e) {
          console.log("---atom parse err:".concat(e));
          reject(new Error('callback result ' + JSON.stringify(jsonMsg) + ' parse error "' + e.message + '",api:' + api + ', maybe is not supported!'));
        }

        if (!res) return resolve(jsonMsg);

        if (res.result && Object.keys(res.result).length > 0) {
          return resolve(res.result);
        } else if (res.errCode && res.errMsg) {
          console.log("atom errcode:".concat(res.errCode, ",msg:").concat(res.errMsg));
          return reject(res);
        } else {
          return resolve(res);
        }
      } else {
        if (Object.keys(jsonMsg).length === 0) {
          console.log("[atom] invoke callback api=".concat(api, " maybe is not supported") + JSON.stringify(jsonMsg));
          invoke('toast', {
            content: '请升级到最新版本，页面体验更佳~'
          });
          return reject(new Error('callback return "' + JSON.stringify(jsonMsg) + '", maybe is not supported!'));
        } else if (jsonMsg.result) {
          return resolve(jsonMsg.result);
        } else {
          return resolve(jsonMsg);
        }
      }
    });

    try {
      if (callbackResult) {
        resolve(JSON.parse(callbackResult));
      }
    } catch (e) {
      console.log("---atom parse err2:".concat(e));
    }
  }).finally(function () {
    finish = true;
  });
} // 缓存事件监听器


var __events = {};

function on(event) {
  var listener = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
  var isOnce = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;
  console.log("[atom] listen event=".concat(event));

  if (typeof listener !== 'function') {
    throw new TypeError('[JSBridge] listener is not a function!');
  }

  if (!__events[event]) {
    __events[event] = [];
    TenvideoJSBridge['on'](event, debounce(exec.bind(null, event, isOnce), 60));
  }

  var listeners = __events[event];

  if (_indexOf(listeners, listener) === -1) {
    // 避免重复注册事件
    listeners.push({
      listener: listener,
      once: isOnce
    });
  }
}
/**
 * 移除事件存储对象中的监听器
 * @author colynchen
 * @param event
 * @param callback
 */


function off(event) {
  var listener = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
  var listeners = __events[event];

  if (!listeners || !listeners.length) {
    return;
  }

  var index = _indexOf(listeners, listener);

  if (index !== -1) {
    // 解除事件
    listeners.splice(index, 1);
  }
}
/**
 * 执行事件回调
 * @param {String} event      事件名称
 * @param {Boolean} isOnce    是否执行一次
 * @param {Object} jsonText   回调数据
 */


function exec(event, isOnce, jsonText) {
  console.log("[atom] listen callback event=".concat(event, " jsonText=").concat(jsonText));
  var res = {};

  if ((0, _util.isPlainObject)(jsonText)) {
    res = jsonText;
  } else {
    try {
      res = JSON.parse(jsonText);
    } catch (e) {
      console.log("---atom parse err3:".concat(e));
    }
  }

  var $events = __events[event];

  if ($events && $events.length > 0) {
    var len = $events.length;

    for (var i = 0; i < len; i++) {
      if ($events[i] && typeof $events[i].listener === 'function') {
        $events[i].listener(res);

        if ($events[i].once) {
          $events.splice(i, 1, null);
        }
      }
    }

    var tempEvents = [];

    for (var j = 0; j < len; j++) {
      if ($events[j]) {
        tempEvents.push($events[j]);
      }
    }

    __events[event] = tempEvents;
  }
}
/**
 * 判断两个监听器是否一致
 * @param {Array} array 事件数组
 * @param {function} listener 监听器
 */


function _indexOf(array, listener) {
  var result = -1;

  for (var i = 0, len = array.length; i < len; i++) {
    // 由于直接对比 function 在同一场景下多次调用时，会导致两个 function 不相等的情况，故通过转字符串进行对比
    if (array[i].listener.toString() === listener.toString()) {
      result = i;
      break;
    }
  }

  return result;
}