"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.setCacheWithLogin = setCacheWithLogin;
exports.getCacheWithLogin = getCacheWithLogin;
exports.setCache = setCache;
exports.getCache = getCache;

var _index = require("../store/index");

/**
 * 缓存key的获取
 * 由传入的key值和登录的vuid共同决定
 * 保证个性化推荐数据是分离的
 * @param {string} key
 */
function getKey(key) {
  return _index.Store.isLogin ? "VN_VIP_".concat(key, "_").concat(_index.Store._cookie.vuserid || _index.Store._cookie.vqq_vuserid) : "VN_VIP_".concat(key, "_notlogin");
}
/**
 * 缓存key会和用户信息相关
 * @param {string} key
 * @param {Object} data
 */


function setCacheWithLogin(key, data) {
  setCache(getKey(key), data);
}
/**
 * 获取key和用户信息相关
 * @param {string} key
 */


function getCacheWithLogin(key) {
  return getCache(getKey(key));
}
/**
 * 缓存key和用户信息无关
 * @param {string} key
 * @param {object} data
 */


function setCache(key, data) {
  vn.storage.setStorage({
    key: key,
    data: data,
    success: function success() {
      console.log("---setCacheSuc---".concat(key));
    },
    fail: function fail(param) {
      console.log("---setCacheFail---".concat(key) + JSON.stringify(param));
    }
  });
}
/**
 * 获取key和用户信息无关
 * @param {string} key
 */


function getCache(key) {
  return new Promise(function (resolve, reject) {
    vn.storage.getStorage({
      key: key,
      success: function success(param) {
        console.log("---getCacheSuc---".concat(key));
        resolve(param);
      },
      fail: function fail(param) {
        console.log("---getCacheFail---".concat(key));
        reject(new Error(param));
      }
    });
  });
}