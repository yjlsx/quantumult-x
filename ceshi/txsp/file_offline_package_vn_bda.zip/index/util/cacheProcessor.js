"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.firstGetFromCache = firstGetFromCache;

var _cache = require("./cache");

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

/**
 * 缓存读取切片函数
 * @param {Object} options
 */
function firstGetFromCache(_x) {
  return _firstGetFromCache.apply(this, arguments);
}

function _firstGetFromCache() {
  _firstGetFromCache = _asyncToGenerator(
  /*#__PURE__*/
  regeneratorRuntime.mark(function _callee(options) {
    return regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            if (!(options.updateData && options.key)) {
              _context.next = 12;
              break;
            }

            _context.prev = 1;
            _context.next = 4;
            return (0, _cache.getCacheWithLogin)(options.key);

          case 4:
            options.data = _context.sent;
            options.updateData(options.key, options.data);
            _context.next = 10;
            break;

          case 8:
            _context.prev = 8;
            _context.t0 = _context["catch"](1);

          case 10:
            _context.next = 13;
            break;

          case 12:
            if (options.getFromCache) {
              try {
                options.data = options.getFromCache();
              } catch (e) {}
            }

          case 13:
            return _context.abrupt("return", options);

          case 14:
          case "end":
            return _context.stop();
        }
      }
    }, _callee, null, [[1, 8]]);
  }));
  return _firstGetFromCache.apply(this, arguments);
}