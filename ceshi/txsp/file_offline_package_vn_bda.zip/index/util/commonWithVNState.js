"use strict";

var _commonReport = require("./commonReport");

// 有状态的common
module.exports = function (vn) {
  var dom = {};
  /**
   * 通用的横滑列表上报函数
   * @param {string} id
   * @param {Array} reportFlag
   */

  var reportListById = function reportListById(id, reportFlag) {
    var list = getDomById(id);

    if ((0, _commonReport.isOnWindow)(list)) {
      var cellDoms = list.getVisibleChildElements();

      var _reportFlag = reportFlag || [];

      cellDoms && cellDoms.forEach(function (item) {
        var dom = item.getVisibleChildElements()[0];

        if (dom) {
          var dataset = dom.getDataSet();

          if (_reportFlag.indexOf(dataset.index) < 0) {
            dom.expose && dom.expose();

            _reportFlag.push(dataset.index);
          }
        }
      });
    }

    return _reportFlag;
  };
  /**
   * id选择器获取dom
   * 会在js内做dom缓存，不必每次都重新获取
   * isStrong用来强制更新js内的缓存
   * @param {string} id
   * @param {boolean} isStrong
   */


  var getDomById = function getDomById(id, isStrong) {
    if (!dom[id] || isStrong) {
      dom[id] = vn.dom.getElementById(id);
    }

    return dom[id];
  };

  return {
    reportListById: reportListById,
    getDomById: getDomById
  };
};