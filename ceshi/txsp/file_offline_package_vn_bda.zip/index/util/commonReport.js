"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.reportItem = reportItem;
exports.isOnWindow = isOnWindow;

var _index = require("../store/index");

var atom = _interopRequireWildcard(require("./atom"));

var _action = require("../store/action");

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = Object.defineProperty && Object.getOwnPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : {}; if (desc.get || desc.set) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } } newObj.default = obj; return newObj; } }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

/**
 * 对节点进行上报
 * 一个节点可以上报多个事件
 * @param {*} params
 */
function reportItem(params) {
  if (params.reportType || params.dataset && params.dataset.reportType) {
    var reportType = params.reportType || params.dataset && params.dataset.reportType;

    if (typeof reportType === 'string') {
      reportType = JSON.parse(reportType);
    }

    var reportData = getReportData(params, reportType);

    if (Array.isArray(reportType.event)) {
      reportType.event.forEach(function (item) {
        doReport({
          eventID: item,
          eventParams: reportData
        });
      });
    } else {
      doReport({
        eventID: reportType.event,
        eventParams: reportData
      });
    }

    return {
      reportType: reportType,
      reportData: reportData
    };
  } else {
    console.log('---err:reportNeedEvent---');
  }
}
/**
 * 执行上报api调用
 * @param {*} params
 */


function doReport(params) {
  if (params.eventID === _index.Store.reportEvent.posterExpose) {
    _action.storeAction.reportJceLoad('posterExpose');
  }

  if (typeof VipVnJsBridge !== 'undefined' && VipVnJsBridge.reportEvent) {
    VipVnJsBridge.reportEvent(params);
  } else {
    atom.invoke('reportEvent', params, {
      notNeedLog: true
    });
  }
}
/**
 * 处理节点信息，获取上报数据
 * @param {*} params
 * @param {*} reportType
 */


function getReportData(params, reportType) {
  var cmsdata = params.cmsdata || params.dataset && params.dataset.cmsdata; // console.log(typeof cmsdata)

  var reportData = {
    reportKey: cmsdata.reportKey || cmsdata.report_key || cmsdata.b_report_key,
    reportParams: cmsdata.reportParams || cmsdata.report_param || cmsdata.b_report_param
  };

  if (reportType && reportType.needAdv) {
    reportData = _extends({
      ptag: cmsdata.ptag,
      f_cubeid: cmsdata.f_cubeid,
      f_item: cmsdata.f_item,
      businessKey: cmsdata.businessKey
    }, reportData);
  }

  return reportData;
}
/**
 * 判断vndom节点是否在屏幕上
 * @param {vndom} dom
 */


function isOnWindow(dom) {
  if (dom && dom.isAttachedToWindow && dom.isAttachedToWindow()) {
    var react = dom.getBoundingClientRect();

    if (react.top < _index.Store.ScreenHeight && react.bottom > 0 && react.left < _index.Store.ScreenWidth && react.right > 0) {
      return true;
    }
  }

  return false;
}