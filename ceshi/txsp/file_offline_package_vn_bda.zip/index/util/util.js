"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.trim = trim;
exports.time33 = time33;
exports.isPlainObject = isPlainObject;
exports.compareVersion = compareVersion;
exports.parseCookie = parseCookie;
exports.concatCookie = concatCookie;
exports.getUrlParam = getUrlParam;
exports.setUrlParam = setUrlParam;
exports.timeOut = timeOut;
exports.stringifyError = stringifyError;
exports.reportErr = reportErr;
exports.reportJceLoad = reportJceLoad;
exports.createKVString = createKVString;

var atom = _interopRequireWildcard(require("./atom"));

var _index = require("../store/index");

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = Object.defineProperty && Object.getOwnPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : {}; if (desc.get || desc.set) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } } newObj.default = obj; return newObj; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

/**
 * 去字符串前后空格
 * @returns {String}
 */
function trim() {
  var str = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
  return str.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, '');
}
/**
 * 哈希time33算法
 * @param {String} key
 * @returns hash code
 */


function time33(key) {
  for (var i = 0, len = key.length, hash = 5381; i < len; ++i) {
    hash += (hash << 5) + key.charAt(i).charCodeAt(0);
  }

  return hash & 0x7fffffff;
}

var oo = {};
var toString = oo.toString;
var hasOwn = oo.hasOwnProperty;
var fnToString = hasOwn.toString;
/**
 * 判断是否是简单对象
 * @param {*} obj
 */

function isPlainObject(obj) {
  if (!obj || toString.call(obj) !== '[object Object]') {
    return false;
  }

  var proto = Object.getPrototypeOf(obj);

  if (!proto) {
    return true;
  }

  var _constructor = hasOwn.call(proto, 'constructor') && proto.constructor;

  return typeof _constructor === 'function' && fnToString.call(_constructor) === fnToString.call(Object);
}
/**
 * 对比 app 版本 A是否大于等于B
 * @param {String} versionA
 * @param {String} versionB
 */


function compareVersion(versionA, versionB) {
  var verA = versionA.split('.');
  var verB = versionB.split('.');
  var len = Math.min(verA.length, verB.length);

  for (var i = 0; i < len; i++) {
    if (verA[i] !== verB[i]) {
      return verA[i] > verB[i];
    }
  }

  return true;
}
/**
 * 解析cookie
 * @param {cookie} content
 */


function parseCookie() {
  var content = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : document.cookie;

  if (!content) {
    return {};
  }

  var reg = /([^;=\s]+)=([^;]*)/g;
  var result = {};
  var match; // eslint-disable-next-line

  while (match = reg.exec(content)) {
    result[match[1]] = match[2];
  }

  return result;
}
/**
 * 多段cookie连接
 * @param  {...any} cookies
 */


function concatCookie() {
  for (var _len = arguments.length, cookies = new Array(_len), _key = 0; _key < _len; _key++) {
    cookies[_key] = arguments[_key];
  }

  return cookies.reduce(function (result, cookie) {
    // 如果不是;结尾，补充;
    if (cookie.slice(-1) !== ';') {
      return result + cookie + ';';
    }

    return result + cookie;
  }, '');
}
/**
 * 从URL中获取指定的参数值
 *
 * @param {String}
 *          p url参数
 * @param {String}
 *          u url 默认为当前url，可为空，如果传入该变量，将从该变量中查找参数p
 * @return {String} 返回的参数值
 */


function getUrlParam(p, u) {
  u = u || location.href;
  var reg = new RegExp("[?&#]".concat(p, "=([^&#]+)"), 'gi');
  var matches = u.match(reg);
  var strArr;

  if (matches && matches.length > 0) {
    strArr = matches[matches.length - 1].split('=');

    if (strArr && strArr.length > 1) {
      // 过滤XSS字符
      return filterXSS(strArr[1]);
    }

    return '';
  }

  return '';
}
/**
 * 设置url中指定的参数
 *
 * @param {string}
 *          name [参数名]
 * @param {string}
 *          value [参数值]
 * @param {string}
 *          url [发生替换的url地址|默认为location.href]
 * @return {string} [返回处理后的url]
 */


function setUrlParam(name, value, url) {
  url = url || location.href;
  var reg = new RegExp("[?&#]".concat(name, "=([^&#]*)"), 'gi');
  var matches = url.match(reg);
  var key = "{key".concat(new Date().getTime(), "}");
  var strArr;

  if (matches && matches.length > 0) {
    strArr = matches[matches.length - 1];
  } else {
    strArr = '';
  }

  var extra = "".concat(name, "=").concat(value); // 当原url中含有要替换的属性:value不为空时，仅对值做替换,为空时，直接把参数删除掉

  if (strArr) {
    var first = strArr.charAt(0);
    url = url.replace(strArr, key);
    url = url.replace(key, value ? first + extra : '');
  } else if (value) {
    // 当原url中不含有要替换的属性且value值不为空时,直接在url后面添加参数字符串
    if (url.indexOf('?') > -1) {
      url += "&".concat(extra);
    } else {
      url += "?".concat(extra);
    }
  } // 其它情况直接返回原url


  return url;
}
/**
 * 过滤XSS
 *
 * @param {string}
 *          str
 * @return {}
 */


function filterXSS(str) {
  return str.replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&apos;');
}

function timeOut(func, time) {
  var args = Array.prototype.slice.call(arguments);
  setTimeout(function () {
    func.apply(void 0, _toConsumableArray(args.slice(2)));
  }, time);
}
/**
 * 返回错误的字符串信息并进行上报
 * @param {Error} e
 * @param {String} event
 */


function stringifyError(e, event) {
  var str = '';

  if (e instanceof Error) {
    str = "message:".concat(e.message, ",stack:").concat(e.stack);
    reportErr(e, event);
    return str;
  }

  str = JSON.stringify(e);
  reportErr(e, event);
  return str;
}
/**
 * 上报错误信息
 * @param {Error} e
 * @param {String} event
 */


function reportErr(e, event) {
  var hasMessage = !!e.message;
  var hasStack = !!e.stack;
  var errString = e;

  if (typeof e !== 'string' && !(e instanceof Error)) {
    try {
      errString = JSON.stringify(e);
    } catch (e) {
      console.log('--reportErrStringifyErr--' + stringifyError(e));
      return;
    }
  }

  atom.invoke('reportEvent', {
    eventID: event || 'vn_vip_program_error',
    eventParams: {
      page: 'vip-channel',
      message: hasMessage ? e.message : errString,
      version: _index.Store.H5Version,
      stack: hasStack ? e.stack : errString
    }
  });
}
/**
 * 用于海报曝光丢失定位损失率
 * @param {string} info
 */


function reportJceLoad(info) {
  atom.invoke('reportEvent', {
    eventID: 'video_jce_poster_load',
    eventParams: {
      reportParams: "&mod_id=".concat(info, "&ztid=100137&page_id=ViptabVnShow_10037"),
      reportKey: "server_personal_page_item_secondpage_".concat(_index.Store.channelId)
    }
  });
}

function createKVString(data) {
  var partitionKey = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '&';
  var valueKey = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : '=';

  if (_typeof(data) !== 'object') {
    return '';
  }

  if (Object.keys(data).length > 0) {
    var res = '';
    Object.keys(data).forEach(function (element) {
      res += "".concat(element).concat(valueKey).concat(data[element]).concat(partitionKey);
    });
    return res;
  }

  return '';
}