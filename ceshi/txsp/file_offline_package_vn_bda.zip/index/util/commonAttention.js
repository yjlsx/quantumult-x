"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.changeAttention = changeAttention;
exports.queryAttention = queryAttention;

var atom = _interopRequireWildcard(require("./atom"));

var _index = require("../store/index");

var _commonReport = require("./commonReport");

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = Object.defineProperty && Object.getOwnPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : {}; if (desc.get || desc.set) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } } newObj.default = obj; return newObj; } }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

/**
   * 改变关注专辑
   * @param {object} item
   * @param {string} attentType  attentType（0：预约，1：收藏）
   */
function changeAttention(_x, _x2) {
  return _changeAttention.apply(this, arguments);
}
/**
   * 获取专辑列表是否在用户的关注列表内
   * @param {Array} dataList
   */


function _changeAttention() {
  _changeAttention = _asyncToGenerator(
  /*#__PURE__*/
  regeneratorRuntime.mark(function _callee(item, attentType) {
    var res;
    return regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            // 取消or添加关注需要单独上报
            try {
              (0, _commonReport.reportItem)({
                cmsdata: {
                  reportKey: item.cms_data.b_report_key,
                  reportParams: item.cms_data.b_report_param
                },
                reportType: {
                  event: _index.Store.reportEvent.buttonClick
                }
              });
            } catch (e) {
              console.log("----reportChangeAttentionErr----".concat(JSON.stringify(e)));
            }

            _context.next = 3;
            return atom.invoke('changeAttention', {
              attentKey: item.cms_data.attent_key,
              posterTitle: item.cms_data.title,
              posterImageUrl: item.cms_data.pic_680x382,
              cid: item.cms_data.cid,
              vid: item.cms_data.vid,
              posterActionUrl: item.cms_data.app_url,
              attentState: item.status,
              attentType: attentType || '1',
              attentTips: attentType === '0' ? '预约成功，上映之后VIP频道可查看，也可关注“腾讯视频VIP”公众号接收通知哦' : ''
            });

          case 3:
            res = _context.sent;

            if (!(+res.ret === 0)) {
              _context.next = 6;
              break;
            }

            return _context.abrupt("return", item.status === '1' ? '0' : '1');

          case 6:
            return _context.abrupt("return", item.status);

          case 7:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));
  return _changeAttention.apply(this, arguments);
}

function queryAttention(_x3) {
  return _queryAttention.apply(this, arguments);
}

function _queryAttention() {
  _queryAttention = _asyncToGenerator(
  /*#__PURE__*/
  regeneratorRuntime.mark(function _callee2(dataList) {
    var attentionList, res;
    return regeneratorRuntime.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            attentionList = [];
            dataList.forEach(function (item, index) {
              if (item) {
                var cmsData = item.cms_data;
                attentionList.push({
                  attentKey: cmsData.attent_key,
                  posterTitle: cmsData.title,
                  posterImageUrl: cmsData.pic_680x382,
                  cid: cmsData.cid,
                  vid: cmsData.vid,
                  posterActionUrl: cmsData.app_url
                });
              }
            });
            _context2.prev = 2;
            _context2.next = 5;
            return atom.invoke('queryAttention', {
              actionType: '0',
              data: attentionList
            }, {
              notNeedLog: true
            });

          case 5:
            res = _context2.sent;
            return _context2.abrupt("return", res);

          case 9:
            _context2.prev = 9;
            _context2.t0 = _context2["catch"](2);
            console.log('---queryAttentionErr---' + JSON.stringify(_context2.t0));
            return _context2.abrupt("return", dataList);

          case 13:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2, null, [[2, 9]]);
  }));
  return _queryAttention.apply(this, arguments);
}