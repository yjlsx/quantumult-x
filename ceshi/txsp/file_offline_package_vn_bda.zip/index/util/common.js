"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.openUrl = openUrl;

var atom = _interopRequireWildcard(require("./atom"));

var util = _interopRequireWildcard(require("./util"));

var _index = require("../store/index");

var _commonReport = require("./commonReport");

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = Object.defineProperty && Object.getOwnPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : {}; if (desc.get || desc.set) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } } newObj.default = obj; return newObj; } }

/**
 * 打开页面函数
 * @param {Object} params
 */
function openUrl(params) {
  var _url = '';

  if (params && params.dataset && params.dataset.url) {
    _url = params.dataset.url;
  } else if (typeof params === 'string') {
    _url = params;
  } // 活动链接添加ptag


  if (_url.indexOf('http') === 0) {
    var ptag = util.getUrlParam('ptag', _url) || 'ad.viptab';
    _url = util.setUrlParam('ptag', ptag, _url);
  } // 拼接伪协议


  if (/^(http|https):\/\/(\S*\.qq\.com|(vurl\.vip))/.test(_url)) {
    _url = "txvideo://v.qq.com/HollywoodH5Activity?url=".concat(encodeURIComponent(_url));
  } else {
    if (/^(http|https):\/\//.test(_url)) {
      _url = "txvideo://v.qq.com/Html5Activity?url=".concat(encodeURIComponent(_url));
    }
  }

  try {
    // 进行点击上报
    var reportData = (0, _commonReport.reportItem)(params);
    var cmsdata = params.cmsdata || params.dataset && params.dataset.cmsdata;

    if (reportData && params.dataset && params.dataset.needbuildurl) {
      _url = util.setUrlParam('reportKey', reportData.reportData.reportKey, _url); // ios和安卓对url上报参数处理逻辑不同

      if (_index.Store.systemInfo.isIos) {
        _url = util.setUrlParam('source', encodeURIComponent(reportData.reportData.reportParams), _url);
      } else {
        _url = util.setUrlParam('reportParams', encodeURIComponent(reportData.reportData.reportParams), _url);
      }
    } // 如果是启明的活动点击


    if (cmsdata.res_id && util.compareVersion(_index.Store.appInfo.version, '8.2.35')) {
      atom.invoke('addResourceTask', {
        type: 'click',
        user_id: _index.Store._cookie.vuserid || _index.Store._cookie.vqq_vuserid || '',
        res_id: cmsdata.res_id || '',
        task_id: cmsdata.task_id || '',
        data_key: cmsdata.data_key || '',
        time: Date.now() + ''
      });
    }
  } catch (e) {
    console.log("----reportErr----".concat(JSON.stringify(e)));
  }

  atom.invoke('openView', {
    url: _url
  });
  _index.Store.hasClick = true;
}