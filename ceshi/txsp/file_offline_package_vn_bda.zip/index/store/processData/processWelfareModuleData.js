"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.processWelfareModuleData = processWelfareModuleData;

var _index = require("../index");

var _moduleDataConfig = require("../moduleDataConfig");

function processWelfareModuleData(data, size) {
  var vExpansionList = data.vExpansionList || [];
  var marqueeData = [];
  vExpansionList.forEach(function (item) {
    var data = {};
    item = item.cms_data;
    data.reportKey = item.b_report_key;
    data.reportParams = item.b_report_param;
    data.vr_report_rollingtext = item.vr_report_rollingtext;

    switch (item.priority) {
      case '2':
        data.actionUrl = 'https://film.video.qq.com/x/grade/?ovscroll=0&hidetitlebar=1&ptag=ad.viptab';
        data.imageUrl = 'https://puui.qpic.cn/vupload/0/20190411_1554968049087_wy77jsw8ts.png/0';
        data.title = "\u4ECA\u65E5\u5DF2\u6709".concat(item.act_user_num, "\u4EBA\u9886\u53D6\u4E86").concat(item.act_title, "\u798F\u5229");
        break;

      case '3':
        data.actionUrl = item.act_h5_url;
        data.imageUrl = 'https://puui.qpic.cn/vupload/0/20190411_1554968049087_wy77jsw8ts.png/0';
        data.title = "\u4ECA\u65E5\u5DF2\u6709".concat(item.act_user_num, "\u4EBA\u53C2\u4E0E\u4E86").concat(item.act_title, "\u6D3B\u52A8");
        break;

      case '4':
        data.actionUrl = item.act_h5_url;
        data.imageUrl = item.user_url || 'https://puui.qpic.cn/vupload/0/20190325_1553501686233_8nspeck1g4x.png/0';
        data.title = nick(item.user_name) + "".concat(item.act_price / 100, "\u5143\u79D2\u6740\u4E86").concat(item.goods_title);
        break;

      case '5':
        data.actionUrl = item.act_h5_url;
        data.imageUrl = item.user_url || 'https://puui.qpic.cn/vupload/0/20190325_1553501686233_8nspeck1g4x.png/0';
        data.title = nick(item.user_name) + "\u53C2\u4E0E".concat(item.act_title, "\u83B7\u5F97\u4E86").concat(item.goods_title);
        break;

      default:
        break;
    }

    if (data.actionUrl) {
      marqueeData.push(data);
    }
  });
  data.marqueeData = marqueeData;
  var list = data.list;
  var remainder = list.length % _moduleDataConfig.horMaxNum[size];

  if (remainder !== 0) {
    list = list.slice(0, list.length - remainder);
  }

  console.log("---welfareLength---".concat(data.list.length, "-").concat(remainder, "-").concat(list.length, "---"));

  if (list.length === 0) {
    return {
      'sectionType': 'throw',
      cells: [data]
    };
  }

  var welfareData = {
    'sectionType': 'welfareComponent',
    cells: list.map(function (item) {
      return {
        type: 'welfareComponent',
        data: item,
        payVip: _index.Store.payVip
      };
    })
  };
  return [{
    'sectionType': 'moduleTitle',
    cells: [{
      type: 'moduleTitle',
      title: data.cms_data.title ? data.cms_data.title : 'VIP会员福利',
      cmsdata: data.cms_data,
      payVip: _index.Store.payVip
    }]
  }, {
    'sectionType': 'marquee',
    cells: [{
      type: 'marquee',
      marqueeData: marqueeData
    }]
  }, welfareData];
}

function nick(nickname) {
  if (!nickname) return '**';
  var nickArr = Array.from(nickname);
  return nickArr[0] + '**' + nickArr[nickArr.length - 1];
}