"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.processUserInterestModuleData = processUserInterestModuleData;

var _moduleDataConfig = require("../moduleDataConfig");

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function processUserInterestModuleData(_x, _x2) {
  return _processUserInterestModuleData.apply(this, arguments);
}

function _processUserInterestModuleData() {
  _processUserInterestModuleData = _asyncToGenerator(
  /*#__PURE__*/
  regeneratorRuntime.mark(function _callee(data, size) {
    var vExpansionList, moreTagList, i, len, num;
    return regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            if (!(size === _moduleDataConfig.UISizeHuge || size === _moduleDataConfig.UISizeMax)) {
              _context.next = 2;
              break;
            }

            return _context.abrupt("return", {});

          case 2:
            vExpansionList = data.vExpansionList;
            moreTagList = [];
            i = 0;
            len = vExpansionList.length;
            num = _moduleDataConfig.labelNum[size] || 3;

            if (data.list && data.list.length > 0) {
              data.showType = 'normal';

              for (; i < len; i += num) {
                if (vExpansionList.length >= i + num) {
                  moreTagList.push(vExpansionList.slice(i, i + num));
                }
              }
            } else {
              data.showType = 'only';
              num = 2 * num;

              for (; i < len; i += num) {
                if (vExpansionList.length >= i + num) {
                  moreTagList.push(vExpansionList.slice(i, i + num));
                }
              }
            }

            data.moreTagList = moreTagList;
            return _context.abrupt("return", {
              'sectionType': data.type,
              cells: [data]
            });

          case 10:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));
  return _processUserInterestModuleData.apply(this, arguments);
}