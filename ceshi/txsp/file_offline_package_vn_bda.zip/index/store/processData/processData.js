"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.processPayVip = processPayVip;
var EXPIRETIME = 604800000;
var ONEDAY = 86400000;
/**
 * 处理会员信息
 * 返回更适合前端使用的数据格式
 * @param {object} payVip
 */

function processPayVip(payVip) {
  if (payVip && !payVip.hasOwnProperty('beginTime') && !payVip.hasOwnProperty('visitor')) {
    payVip.isRealVip = false;
    return payVip;
  }

  if (payVip.score > 0 && payVip.endTime) {
    payVip.showEndTime = payVip.endTime.split(' ')[0];

    if (payVip.vip === 1) {
      var endTime = new Date(payVip.endTime.replace(/-/g, '/')).setHours(0, 0, 0, 0);
      var today = new Date().setHours(0, 0, 0, 0);
      var expireTime = endTime - today;

      if (expireTime <= EXPIRETIME) {
        payVip.expireDay = parseInt(expireTime / ONEDAY);
      } else {
        payVip.expireDay = -1;
      }
    }
  }

  payVip.isVisitorVip = payVip && payVip.visitor && payVip.visitor.vip === 1 || false;
  payVip.isVip = payVip && +payVip.vip === 1 && +payVip.isVisitorVip === 0;
  payVip.isRealVip = payVip.isVisitorVip || payVip.isVip;
  payVip.isOverTimeVip = payVip && +payVip.vip === 0 && payVip.endTime !== '' && +payVip.isVisitorVip === 0 && payVip.level > 0;
  payVip.isNotVip = payVip && +payVip.vip === 0 && +payVip.level === 0 && +payVip.isVisitorVip === 0;

  if (payVip.isVisitorVip) {
    payVip.visitorShowEndTime = payVip.visitor.endTime.split(' ')[0];
  }

  return payVip;
}