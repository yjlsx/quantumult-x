"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.processLeftPicModuleData = processLeftPicModuleData;

var _moduleDataConfig = require("../moduleDataConfig");

function processLeftPicModuleData(data, size) {
  var num = _moduleDataConfig.leftPicNum[size];
  var moreList = [];
  var list = data.list; // data.list = data.list.splice(0, (parseInt(data.list.length / num) * num))

  var i = 0;
  var len = list.length;

  for (; i < len; i += num) {
    if (list.length >= i + num) {
      moreList.push(list.slice(i, i + num));
    }
  }

  data.moreList = moreList;
  return {
    'sectionType': data.type,
    cells: [data]
  };
}