"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.processFocusModuleData = processFocusModuleData;

var _moduleDataConfig = require("../moduleDataConfig");

/**
 * 焦点图模块数据处理
 * @param {object} data
 * @param {string} size
 */
function processFocusModuleData(data, size) {
  data.list.forEach(function (item, index) {
    item.type += '';

    if (item.type === '122' && item.cms_data.current_play === '1') {
      data.list[index].videoshow = 0;
      data.list[index].videoplay = 0;
      data.list[index].cms_data.videoReport = "reportKey=".concat(encodeURIComponent(item.cms_data.report_key), "&reportParams=").concat(encodeURIComponent(item.cms_data.report_param));
    }

    if (size === _moduleDataConfig.UISizeRegular) {
      item.cms_data.pic_vip = item.cms_data.pic_750x750;
      item.cms_data.pic_novip = item.cms_data.pic_750x422;
    }

    if (size === _moduleDataConfig.UISizeLarge) {
      item.cms_data.pic_vip = item.cms_data.pic_1280x720;
      item.cms_data.pic_novip = item.cms_data.pic_1280x720;
    }

    if (size === _moduleDataConfig.UISizeMax || size === _moduleDataConfig.UISizeHuge) {
      item.cms_data.pic_vip = item.cms_data.pic_2048x926;
      item.cms_data.pic_novip = item.cms_data.pic_2048x926;
    }
  });
  return {
    'sectionType': data.type,
    cells: [data]
  };
}