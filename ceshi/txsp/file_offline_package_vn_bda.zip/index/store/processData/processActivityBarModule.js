"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.processActivityBarModule = processActivityBarModule;

var _moduleDataConfig = require("../moduleDataConfig");

function processActivityBarModule(data, size) {
  // console.log(JSON.stringify(data))
  if (!data.list) {
    console.log("---processActivityBarModule---not have list");
    return {
      'sectionType': 'error'
    };
  }

  if (data.list.length < _moduleDataConfig.activityBarNum[size]) {
    console.log("---processActivityBarModule---list length not enough");
    return {
      'sectionType': 'thtow',
      cells: data
    };
  }

  data.list = data.list.slice(0, _moduleDataConfig.activityBarNum[size]); // data.list.forEach(item => {
  //   console.log(JSON.stringify(item.cms_data))
  // })

  return {
    'sectionType': data.type,
    cells: [data]
  };
}