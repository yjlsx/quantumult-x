"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.processStarModuleData = processStarModuleData;

var _commonAttention = require("../../util/commonAttention");

var _util = require("./util");

var _moduleDataConfig = require("../moduleDataConfig");

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

/**
 * 明星模块数据处理
 * @param {object} data
 * @param {string} size
 */
function processStarModuleData(_x, _x2) {
  return _processStarModuleData.apply(this, arguments);
}

function _processStarModuleData() {
  _processStarModuleData = _asyncToGenerator(
  /*#__PURE__*/
  regeneratorRuntime.mark(function _callee(data, size) {
    var vExpansionList, cidList, attentionList, num;
    return regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            if (!(size === _moduleDataConfig.UISizeHuge || size === _moduleDataConfig.UISizeMax)) {
              _context.next = 2;
              break;
            }

            return _context.abrupt("return", {});

          case 2:
            console.log("---starmodule---1length:".concat(data.vExpansionList.length));
            vExpansionList = data.vExpansionList;
            cidList = data.list;
            cidList = cidList.map(_util.processPosterData);
            _context.next = 8;
            return (0, _commonAttention.queryAttention)(cidList);

          case 8:
            attentionList = _context.sent;
            cidList = (0, _util.updateAttentionList)(cidList, attentionList); // vExpansionList = vExpansionList.concat(vExpansionList) 人工增加数据，调试用
            // 根据尺寸剔除多余数据

            num = _moduleDataConfig.starNum[size];

            if (vExpansionList.length > num) {
              vExpansionList = vExpansionList.slice(0, num);
            }

            console.log("---starmodule---2length:".concat(data.vExpansionList.length, "-").concat(vExpansionList.length)); // 循环处理出每个明星的成就和相关视频

            vExpansionList.forEach(function (starItem, index) {
              var list = cidList.filter(function (posterItem) {
                return posterItem.cms_data.star_id === starItem.itemId;
              });
              list.forEach(function (item) {
                item.cms_data.vr_report_poster = item.cms_data.vr_report_poster.replace('tab_idx=', "tab_idx=".concat(index));
              });
              starItem.cms_data.imageFinal = starItem.cms_data.image_vertical || starItem.cms_data.colorful_pic || starItem.cms_data.image_200x200;
              starItem.list = list;
              var achievementArr = starItem.cms_data.achievement_list && starItem.cms_data.achievement_list.split('|');
              var infoArr = [];
              var _infoArr = [starItem.cms_data.profession, starItem.cms_data.birthday, starItem.cms_data.area, starItem.cms_data.constellation, starItem.cms_data.blood, starItem.cms_data.height];

              for (var i = 0; i < _infoArr.length; i++) {
                var item = _infoArr[i];

                if (+item) {
                  infoArr.push(parseInt(item) + 'CM');
                } else if (item) {
                  infoArr.push(item.split('|')[0]);
                }
              }

              infoArr = [infoArr.join('/')].concat(achievementArr);
              infoArr = infoArr.filter(function (item) {
                return item && item.length > 0;
              });

              if (infoArr.length > 3) {
                infoArr = infoArr.slice(0, 3);
              }

              starItem.infoArr = infoArr;
            });
            data.vExpansionListNew = vExpansionList;
            console.log("---starmodule---3length:".concat(data.vExpansionList.length, "-").concat(vExpansionList.length));
            return _context.abrupt("return", {
              'sectionType': data.type,
              cells: [data]
            });

          case 17:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));
  return _processStarModuleData.apply(this, arguments);
}