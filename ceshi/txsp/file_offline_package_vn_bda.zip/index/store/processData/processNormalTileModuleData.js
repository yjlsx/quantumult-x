"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.processNormalTileModuleData = processNormalTileModuleData;

var _index = require("../index");

var _util = require("./util");

var _moduleDataConfig = require("../moduleDataConfig");

/**
 * 平铺横图模块数据处理
 * @param {object} data
 * @param {string} size
 */
function processNormalTileModuleData(data, size, listIndex) {
  if (data.list.length < _moduleDataConfig.horMaxNum[size]) {
    data.type = 'throw';
    return {
      'sectionType': data.type,
      cells: [data]
    };
  }

  var remainder = data.list.length % _moduleDataConfig.horMaxNum[size];
  var newList = data.list;
  console.log("--processNormalTileModuleData--".concat(listIndex, "--").concat(data.allList && data.allList.length));

  if (remainder !== 0) {
    newList = newList.slice(0, newList.length - remainder);
  }

  if (data.cms_data.pic_type === '2' || data.cms_data.pic_type === '12') {
    data.type = 'type_30014_ver';
  }

  newList = newList.map(_util.processPosterData);
  newList = newList.map(function (item) {
    return (0, _util.processCellTypeData)('horizontalPosterComponent', item);
  });
  var list = [{
    'sectionType': 'horizontalPosterComponent',
    cells: newList,
    allList: data.allList ? data.allList : newList
  }];

  if (data.cms_data.ZT_leaf_shake === '1') {
    list.push({
      'sectionType': 'exchangeComponent',
      cells: [{
        type: 'exchangeComponent',
        cmsData: data.cms_data,
        payVip: _index.Store.payVip,
        shake: {
          step: 0,
          maxStep: data.allList ? Math.floor(data.allList.length / newList.length) : 1,
          shakeStepLength: list[0].cells.length,
          loadFinish: data.loadFinish || false,
          listIndex: listIndex
        }
      }]
    });
  }

  return [{
    'sectionType': 'moduleTitle',
    cells: [{
      type: 'moduleTitle',
      title: data.cms_data.title ? data.cms_data.title : '会员都在看',
      cmsdata: data.cms_data,
      payVip: _index.Store.payVip
    }]
  }].concat(list);
}