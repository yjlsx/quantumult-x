"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.processChannelData = processChannelData;
exports.refreshAllChannelData = refreshAllChannelData;
exports.processModuleListData = processModuleListData;

var _index = require("../index");

var _moduleDataConfig = require("../moduleDataConfig");

var _processWelfareModuleData = require("./processWelfareModuleData");

var _processNormalTileModuleData = require("./processNormalTileModuleData");

var _processUserInterestModuleData = require("./processUserInterestModuleData");

var _processLeftPicModuleData = require("./processLeftPicModuleData");

var _processStarModuleData = require("./processStarModuleData");

var _processUpcomingModuleData = require("./processUpcomingModuleData");

var _processFocusModuleData = require("./processFocusModuleData");

var _processActivityBarModule = require("./processActivityBarModule");

var _util = require("./util");

var _commonAttention = require("../../util/commonAttention");

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

var processFuncs = {
  'type_62': _processFocusModuleData.processFocusModuleData,
  'type_30066': processDailyRecommendModuleData,
  'type_30041': processNormalModuleData,
  'type_30014': _processNormalTileModuleData.processNormalTileModuleData,
  'type_235': _processWelfareModuleData.processWelfareModuleData,
  'type_58': _processUpcomingModuleData.processUpcomingModuleData,
  'type_30062': processFriendsModuleData,
  'type_30060': _processStarModuleData.processStarModuleData,
  'type_30065': _processUserInterestModuleData.processUserInterestModuleData,
  'type_30069': _processLeftPicModuleData.processLeftPicModuleData,
  'type_273': processActivityCardModule,
  'type_30063': _processActivityBarModule.processActivityBarModule
  /**
   * 对外暴露统一的模块数据处理函数
   * @param {object} channelData
   */

};

function processChannelData(_x) {
  return _processChannelData.apply(this, arguments);
}
/**
 * UI尺寸变化时 重新处理已缓存下来的数据
 */


function _processChannelData() {
  _processChannelData = _asyncToGenerator(
  /*#__PURE__*/
  regeneratorRuntime.mark(function _callee(channelData) {
    var isDataArray, modList;
    return regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            isDataArray = Array.isArray(channelData);
            modList = isDataArray ? channelData : channelData.data && channelData.data.modList;

            if (!Array.isArray(modList)) {
              _context.next = 8;
              break;
            }

            _context.next = 5;
            return Promise.all(modList.map(runProcess));

          case 5:
            modList = _context.sent;
            modList = modList.reduce(function (acc, val) {
              return acc.concat(val);
            }, []);

            if (!isDataArray) {
              channelData.data.modList = modList;
            }

          case 8:
            return _context.abrupt("return", isDataArray ? modList : channelData);

          case 9:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));
  return _processChannelData.apply(this, arguments);
}

function refreshAllChannelData() {
  return _refreshAllChannelData.apply(this, arguments);
}

function _refreshAllChannelData() {
  _refreshAllChannelData = _asyncToGenerator(
  /*#__PURE__*/
  regeneratorRuntime.mark(function _callee2() {
    var list;
    return regeneratorRuntime.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _index.Store.listCount = 0;
            console.log("---refreshLength:".concat(_index.Store.listData.length, "---"));
            _context2.next = 4;
            return processChannelData(_index.Store.listData);

          case 4:
            list = _context2.sent;
            console.log('---refreshAllChannelData---');

            if (list && list.length > 0) {
              console.log(list);

              _index.Store.__vn.data.update('listData', list);
            }

            return _context2.abrupt("return", list);

          case 8:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2);
  }));
  return _refreshAllChannelData.apply(this, arguments);
}

function processModuleListData(_x2) {
  return _processModuleListData.apply(this, arguments);
}
/**
 * 逐个处理每个模块数据
 * 根据type做分发
 * @param {object} item
 */


function _processModuleListData() {
  _processModuleListData = _asyncToGenerator(
  /*#__PURE__*/
  regeneratorRuntime.mark(function _callee3(list) {
    var attentionList;
    return regeneratorRuntime.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.next = 2;
            return (0, _commonAttention.queryAttention)(list);

          case 2:
            attentionList = _context3.sent;
            return _context3.abrupt("return", (0, _util.updateAttentionList)(list, attentionList));

          case 4:
          case "end":
            return _context3.stop();
        }
      }
    }, _callee3);
  }));
  return _processModuleListData.apply(this, arguments);
}

function runProcess(item) {
  console.log("---runProcess:".concat(item.type, "-").concat(_moduleDataConfig.ModuleName[item.type] || '', "-").concat(item.cms_data && item.cms_data.title, "---"));

  if (typeof processFuncs[item.type] === 'function') {
    return processFuncs[item.type](item, _index.Store.uiSize, _index.Store.listCount++);
  } else {
    console.log("---do not have processer---".concat(item.type));
    return {
      'sectionType': item.type,
      cells: [item]
    };
  }
}
/**
 * 每日推荐模块数据处理
 * @param {object} data
 * @param {string} size
 */


function processDailyRecommendModuleData(_x3, _x4) {
  return _processDailyRecommendModuleData.apply(this, arguments);
}
/**
 * 普通的横滑模块模块数据处理
 * @param {object} data
 * @param {string} size
 */


function _processDailyRecommendModuleData() {
  _processDailyRecommendModuleData = _asyncToGenerator(
  /*#__PURE__*/
  regeneratorRuntime.mark(function _callee4(data, size) {
    var attentionList, today;
    return regeneratorRuntime.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            data.list = data.list.map(_util.processPosterData);
            _context4.next = 3;
            return (0, _commonAttention.queryAttention)(data.list);

          case 3:
            attentionList = _context4.sent;
            data.list = (0, _util.updateAttentionList)(data.list, attentionList);

            if (data.cms_data.now) {
              today = new Date(+data.cms_data.now * 1000);
            } else {
              today = new Date();
            }

            data.cms_data.month = _moduleDataConfig.Month[today.getMonth()];
            data.cms_data.day = today.getDate();
            return _context4.abrupt("return", {
              'sectionType': data.type,
              cells: [data]
            });

          case 9:
          case "end":
            return _context4.stop();
        }
      }
    }, _callee4);
  }));
  return _processDailyRecommendModuleData.apply(this, arguments);
}

function processNormalModuleData(data, size) {
  if (data.cms_data.pic_type !== '2' && data.cms_data.pic_type !== '12') {
    data.type = 'type_30041_hori';
  }

  data.list = data.list.map(_util.processPosterData);
  return {
    'sectionType': data.type,
    cells: [data]
  };
}
/**
 * 好友模块数据处理
 * @param {object} data
 * @param {string} size
 */


function processFriendsModuleData(_x5, _x6) {
  return _processFriendsModuleData.apply(this, arguments);
}
/**
 * 推广位卡片模块数据处理
 * @param {object} data
 * @param {string} size
 */


function _processFriendsModuleData() {
  _processFriendsModuleData = _asyncToGenerator(
  /*#__PURE__*/
  regeneratorRuntime.mark(function _callee5(data, size) {
    var headerList, attentionList;
    return regeneratorRuntime.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            headerList = data.cms_data.icon_list.split('|');
            data.headerList = headerList;
            data.list = data.list.map(_util.processPosterData);
            _context5.next = 5;
            return (0, _commonAttention.queryAttention)(data.list);

          case 5:
            attentionList = _context5.sent;
            data.list = (0, _util.updateAttentionList)(data.list, attentionList);
            return _context5.abrupt("return", {
              'sectionType': data.type,
              cells: [data]
            });

          case 8:
          case "end":
            return _context5.stop();
        }
      }
    }, _callee5);
  }));
  return _processFriendsModuleData.apply(this, arguments);
}

function processActivityCardModule(data, size) {
  if (data.list.length < 2) {
    data.type = 'throw';
  }

  return {
    'sectionType': data.type,
    cells: [data]
  };
}