"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.processPosterData = processPosterData;
exports.processCellTypeData = processCellTypeData;
exports.updateAttentionList = updateAttentionList;

var _index = require("../index");

var _util = require("../../util/util");

function processPosterData(data, size) {
  var type = data.cms_data.type;

  if (+type === 1 || +type === 9) {
    var score = data.cms_data.score;

    if (+score > 0) {
      data.cms_data.score = (+score).toFixed(1);
      return data;
    }

    try {
      var parseScore = JSON.parse(data.cms_data.score);
      score = parseScore.hot || parseScore.c_mix_score;

      if (+score > 0) {
        data.cms_data.score = (+score).toFixed(1);
        return data;
      }
    } catch (e) {
      console.log("--parseScoreError--" + (0, _util.stringifyError)(e));
    }

    data.cms_data.score = '';
  }

  return data;
}

function processCellTypeData(type, data) {
  return {
    type: type,
    data: data,
    payVip: _index.Store.payVip
  };
}

function updateAttentionList(dataList, attentionList) {
  dataList.forEach(function (item, index) {
    if (item && item.status !== '2') {
      dataList[index].status = attentionList[index].attentState;
    }
  });
  return dataList;
}