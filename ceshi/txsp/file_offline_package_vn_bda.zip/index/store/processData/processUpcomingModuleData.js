"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.processUpcomingModuleData = processUpcomingModuleData;

var _commonAttention = require("../../util/commonAttention");

var _util = require("./util");

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

/**
 * 即将上映模块数据处理
 * @param {object} data
 * @param {string} size
 */
function processUpcomingModuleData(_x, _x2) {
  return _processUpcomingModuleData.apply(this, arguments);
}

function _processUpcomingModuleData() {
  _processUpcomingModuleData = _asyncToGenerator(
  /*#__PURE__*/
  regeneratorRuntime.mark(function _callee(data, size) {
    var attentionList;
    return regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            data.list.forEach(function (item, index) {
              var cmsData = item.cms_data;

              try {
                if (cmsData.finishDate) return;

                if (cmsData.show_date) {
                  var dateArr = cmsData.show_date.split(' ');
                  var date = new Date(cmsData.show_date.replace(/-/g, '/'));
                  var today = new Date();

                  if (date < today) {
                    item.status = '2';
                  } else {
                    item.status = '0';
                  }

                  var todayUtc = today.setHours(0, 0, 0, 0);
                  var dateUtc = date.setHours(0, 0, 0, 0);

                  if (todayUtc === dateUtc) {
                    cmsData.isToday = true;
                    cmsData.show_date = '今日 ' + dateArr[1].slice(0, 5);
                  } else if (todayUtc - dateUtc === -86400000) {
                    cmsData.show_date = '明日 ' + dateArr[1].slice(0, 5);
                  } else {
                    cmsData.show_date = dateArr[0].replace(/\//g, '.').slice(5, 10);
                  }

                  cmsData.finishDate = true;
                } else {
                  item.status = '0';
                  cmsData.show_date = cmsData.show_text;
                }
              } catch (e) {
                item.status = '0';
                cmsData.show_date = cmsData.show_text;
                console.log('----updateDatalistErr:' + JSON.stringify(e));
              }

              item.cms_data = cmsData;
              data.list[index] = item;
            });
            _context.next = 3;
            return (0, _commonAttention.queryAttention)(data.list);

          case 3:
            attentionList = _context.sent;
            data.list = (0, _util.updateAttentionList)(data.list, attentionList);
            return _context.abrupt("return", {
              'sectionType': data.type,
              cells: [data]
            });

          case 6:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));
  return _processUpcomingModuleData.apply(this, arguments);
}