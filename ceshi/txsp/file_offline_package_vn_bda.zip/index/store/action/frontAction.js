"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getCookie = getCookie;
exports.getSystemInfo = getSystemInfo;
exports.getAppInfo = getAppInfo;
exports.getPullRefreshData = getPullRefreshData;
exports.getScreenSize = getScreenSize;
exports.checkLogin = checkLogin;

var _index = require("../index");

var atom = _interopRequireWildcard(require("../../util/atom"));

var _util = require("../../util/util");

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = Object.defineProperty && Object.getOwnPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : {}; if (desc.get || desc.set) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } } newObj.default = obj; return newObj; } }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance"); }

function _iterableToArrayLimit(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

/**
 * 获取cookie存入store
 */
function getCookie() {
  return _getCookie.apply(this, arguments);
} // todo 装饰器优化 调用缓存

/**
 * 获取网络状态，系统版本等系统信息
 */


function _getCookie() {
  _getCookie = _asyncToGenerator(
  /*#__PURE__*/
  regeneratorRuntime.mark(function _callee() {
    var deviceInfo, mainCookie, cookie;
    return regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.prev = 0;
            _context.next = 3;
            return atom.invoke('getDeviceInfo');

          case 3:
            deviceInfo = _context.sent;
            _context.next = 6;
            return atom.invoke('getMainCookie');

          case 6:
            mainCookie = _context.sent;
            _context.next = 9;
            return atom.invoke('getCookie', {
              'type': ['tv']
            });

          case 9:
            cookie = _context.sent;
            _index.Store.cookie = (0, _util.concatCookie)(mainCookie.cookie || '', cookie.tv, "omgid=".concat(deviceInfo.omgid, ";") + (_index.Store.isLogin ? 'main_login=' + (_index.Store.userInfo && _index.Store.userInfo.type || '') + ';' : ''));
            _index.Store.deviceInfo = deviceInfo;
            console.log("---cookie---".concat(_index.Store.cookie));
            _index.Store._cookie = (0, _util.parseCookie)(_index.Store.cookie);
            _context.next = 22;
            break;

          case 16:
            _context.prev = 16;
            _context.t0 = _context["catch"](0);
            _index.Store.deviceInfo = deviceInfo;
            _index.Store.cookie = '';
            _index.Store._cookie = {};
            console.log("---getCookieErr---".concat(JSON.stringify(_context.t0)));

          case 22:
            return _context.abrupt("return", _index.Store.cookie);

          case 23:
          case "end":
            return _context.stop();
        }
      }
    }, _callee, null, [[0, 16]]);
  }));
  return _getCookie.apply(this, arguments);
}

function getSystemInfo() {
  return _getSystemInfo.apply(this, arguments);
}
/**
 * 获取app版本等信息
 */


function _getSystemInfo() {
  _getSystemInfo = _asyncToGenerator(
  /*#__PURE__*/
  regeneratorRuntime.mark(function _callee2() {
    var ChannelPageInfo, networkState, height, _ref, _ref2;

    return regeneratorRuntime.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.prev = 0;

            if (!(_index.Store.appInfo && (0, _util.compareVersion)(_index.Store.appInfo.version, '7.3.0'))) {
              _context2.next = 11;
              break;
            }

            _context2.next = 4;
            return Promise.all([atom.invoke('getChannelPageInfo'), atom.invoke('getNetworkState')]);

          case 4:
            _ref = _context2.sent;
            _ref2 = _slicedToArray(_ref, 2);
            ChannelPageInfo = _ref2[0];
            networkState = _ref2[1];
            height = +ChannelPageInfo.navViewheight * 2 || 200;
            _context2.next = 15;
            break;

          case 11:
            _context2.next = 13;
            return atom.invoke('getNetworkState');

          case 13:
            networkState = _context2.sent;
            height = 200;

          case 15:
            _context2.next = 20;
            break;

          case 17:
            _context2.prev = 17;
            _context2.t0 = _context2["catch"](0);
            console.log("--getOtherSystemInfoFail--".concat(JSON.stringify(_context2.t0)));

          case 20:
            _index.Store.__vn.data.update('videoTopHeight', height);

            _index.Store.networkState = networkState;
            _index.Store.systemInfo = {};
            return _context2.abrupt("return", new Promise(function (resolve) {
              _index.Store.__vn.getSystemInfo({
                success: function success(param) {
                  console.log("---getSystemInfo---".concat(JSON.stringify(param)));
                  _index.Store.systemInfo = param;
                  _index.Store.systemInfo.isIos = _index.Store.systemInfo.platform === 'ios';
                  _index.Store.systemInfo.isIpad = _index.Store.systemInfo.isIos && _index.Store.systemInfo.brand !== 'iPhone';

                  if (_index.Store.systemInfo.isIos) {
                    _index.Store.systemInfo.iosVersion = _index.Store.systemInfo.system.split(' ')[1];
                  }

                  _index.Store.__vn.data.update('systemInfo', param);

                  return resolve(param);
                },
                fail: function fail(param) {
                  console.log("--getSystemInfoFail--".concat(JSON.stringify(param)));
                  return resolve(param);
                }
              });
            }));

          case 24:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2, null, [[0, 17]]);
  }));
  return _getSystemInfo.apply(this, arguments);
}

function getAppInfo() {
  return _getAppInfo.apply(this, arguments);
}
/**
 * 获取下拉刷新配置信息，用于下拉刷新展示
 */


function _getAppInfo() {
  _getAppInfo = _asyncToGenerator(
  /*#__PURE__*/
  regeneratorRuntime.mark(function _callee3() {
    var appInfo;
    return regeneratorRuntime.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.next = 2;
            return atom.invoke('getAppInfo');

          case 2:
            appInfo = _context3.sent;
            appInfo.version = appInfo.version.split('.').slice(0, 3).join('.');
            _index.Store.appInfo = appInfo;
            return _context3.abrupt("return", appInfo);

          case 6:
          case "end":
            return _context3.stop();
        }
      }
    }, _callee3);
  }));
  return _getAppInfo.apply(this, arguments);
}

function getPullRefreshData() {
  return _getPullRefreshData.apply(this, arguments);
}
/**
 * 获取屏幕尺寸，用于计算dom节点是否在屏幕上
 * @param {Object} indexPage
 */


function _getPullRefreshData() {
  _getPullRefreshData = _asyncToGenerator(
  /*#__PURE__*/
  regeneratorRuntime.mark(function _callee4() {
    var pullRefreshData;
    return regeneratorRuntime.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.next = 2;
            return atom.invoke('getPullRefreshData');

          case 2:
            pullRefreshData = _context4.sent;
            _index.Store.pullRefreshData = pullRefreshData || {};

            _index.Store.__vn.data.update('pullRefreshData', pullRefreshData);

          case 5:
          case "end":
            return _context4.stop();
        }
      }
    }, _callee4);
  }));
  return _getPullRefreshData.apply(this, arguments);
}

function getScreenSize(indexPage) {
  if (!_index.Store.ScreenHeight) {
    var react = indexPage.dom.modList.getBoundingClientRect();
    _index.Store.ScreenWidth = react.width;
    _index.Store.ScreenHeight = react.height;
  }
} // todo 装饰器优化 调用缓存


function checkLogin() {
  return _checkLogin.apply(this, arguments);
}

function _checkLogin() {
  _checkLogin = _asyncToGenerator(
  /*#__PURE__*/
  regeneratorRuntime.mark(function _callee5() {
    var userInfo;
    return regeneratorRuntime.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            _context5.prev = 0;
            _context5.next = 3;
            return atom.invoke('getMainUserInfo');

          case 3:
            userInfo = _context5.sent;
            userInfo.userInfo.type = userInfo.type;
            userInfo.userInfo.headImgUrl = userInfo.userInfo.headImgUrl || 'https://puui.qpic.cn/vupload/0/20190325_1553501686233_8nspeck1g4x.png/0';
            userInfo.userInfo.avatarPendant = userInfo.userInfo.avatarPendant || '';

            _index.Store.__vn.data.update('userInfo', userInfo.userInfo);

            _index.Store.__vn.data.update('isLogin', true);

            _index.Store.isLogin = true;
            _index.Store.userInfo = userInfo;
            _context5.next = 17;
            break;

          case 13:
            _context5.prev = 13;
            _context5.t0 = _context5["catch"](0);
            _index.Store.isLogin = false;

            _index.Store.__vn.data.update('isLogin', false);

          case 17:
            console.log('---checkLoginFinish:' + _index.Store.isLogin);
            return _context5.abrupt("return", _index.Store.isLogin);

          case 19:
          case "end":
            return _context5.stop();
        }
      }
    }, _callee5, null, [[0, 13]]);
  }));
  return _checkLogin.apply(this, arguments);
}