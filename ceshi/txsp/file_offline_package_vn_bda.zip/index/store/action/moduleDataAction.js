"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getChannelDataFromCache = getChannelDataFromCache;
exports.getChannelData = getChannelData;
exports.getModuleData = getModuleData;

var _index = require("../index");

var _moduleDataConfig = require("../moduleDataConfig");

var channelService = _interopRequireWildcard(require("../../service/channelService"));

var _cache = require("../../util/cache");

var _util = require("../../util/util");

var _processChannelData = require("../processData/processChannelData");

var _util2 = require("/index/store/processData/util");

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = Object.defineProperty && Object.getOwnPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : {}; if (desc.get || desc.set) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } } newObj.default = obj; return newObj; } }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance"); }

function _iterableToArrayLimit(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

/**
 * 从缓存获取频道数据
 */
function getChannelDataFromCache() {
  return _getChannelDataFromCache.apply(this, arguments);
}
/**
 * 获取频道数据
 * 这里会添加函数
 * @param {object} param
 */


function _getChannelDataFromCache() {
  _getChannelDataFromCache = _asyncToGenerator(
  /*#__PURE__*/
  regeneratorRuntime.mark(function _callee() {
    var _ref2, _ref3, _channelData, _listData;

    return regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.prev = 0;
            _context.next = 3;
            return Promise.all([(0, _cache.getCache)('VN_VIP_channelData'), (0, _cache.getCache)('VN_VIP_listData')]);

          case 3:
            _ref2 = _context.sent;
            _ref3 = _slicedToArray(_ref2, 2);
            _channelData = _ref3[0];
            _listData = _ref3[1];

            _index.Store.__vn.data.update('listData', _listData);

            _index.Store.channelData = _channelData;
            _context.next = 13;
            break;

          case 11:
            _context.prev = 11;
            _context.t0 = _context["catch"](0);

          case 13:
          case "end":
            return _context.stop();
        }
      }
    }, _callee, null, [[0, 11]]);
  }));
  return _getChannelDataFromCache.apply(this, arguments);
}

function getChannelData(_x, _x2) {
  return _getChannelData.apply(this, arguments);
}

function _getChannelData() {
  _getChannelData = _asyncToGenerator(
  /*#__PURE__*/
  regeneratorRuntime.mark(function _callee2(param, indexPage) {
    var channelData, list, _Store$__vn$data;

    return regeneratorRuntime.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.prev = 0;
            console.log("---action.getChannelData---".concat(JSON.stringify(param)));
            _context2.next = 4;
            return channelService.getChannelData(_extends(param, {
              seqNum: _index.Store.channelData && _index.Store.channelData.data && _index.Store.channelData.data.seqNum,
              expansion: "device_type=".concat(_moduleDataConfig.UISizeMap[_index.Store.maxUiSize]) || 'device_type=1'
            }));

          case 4:
            channelData = _context2.sent;

            if (channelData.data) {
              _context2.next = 8;
              break;
            }

            console.log(JSON.stringify(channelData));
            throw new Error('---getChannelDataErr---(data:null)');

          case 8:
            if (!(channelData.data && channelData.data.pageContext === '-1')) {
              _context2.next = 10;
              break;
            }

            throw new Error('---getChannelDataErr---(-1)');

          case 10:
            _context2.next = 19;
            break;

          case 12:
            _context2.prev = 12;
            _context2.t0 = _context2["catch"](0);
            indexPage.data.requestErr = true;
            indexPage.data.loadFinish = true;
            _index.Store.__vn.dom.getElementById('mod_list') && _index.Store.__vn.dom.getElementById('mod_list').setFooterRefreshingEnabled(false);

            _index.Store.__vn.data.update('footerLottie', false);

            console.log("---getChannelDataErrRequest---" + (0, _util.stringifyError)(_context2.t0));

          case 19:
            _context2.prev = 19;
            _index.Store.channelData = channelData;
            console.log("---channelDataseqNumRes:".concat(channelData.data && channelData.data.seqNum, "---pageContextReq:").concat(param && param.pageContext, "-").concat(!param.pageContext));

            if (!(channelData.data && channelData.data.modList && channelData.data.modList.length > 0)) {
              _context2.next = 31;
              break;
            }

            list = channelData.data.modList; // 缓存原始数据

            _index.Store.listData = _index.Store.listData.concat(list);
            _context2.next = 27;
            return (0, _processChannelData.processChannelData)(channelData);

          case 27:
            channelData = _context2.sent;
            list = channelData.data.modList;

            if (!param.pageContext) {
              // 首页请求
              _index.Store.useNewData = true;

              _index.Store.__vn.data.update('listData', list); // 异步写外存 防止数据穿透影响主进程


              (0, _util.timeOut)(_cache.setCache, 300, 'VN_VIP_listData', list);
              (0, _util.timeOut)(_cache.setCache, 500, 'VN_VIP_channelData', channelData);
            } else {
              (_Store$__vn$data = _index.Store.__vn.data).append.apply(_Store$__vn$data, ['listData'].concat(_toConsumableArray(list)));
            }

            console.log(channelData.data.modList.map(function (item) {
              return item.sectionType;
            }));

          case 31:
            return _context2.abrupt("return", channelData);

          case 34:
            _context2.prev = 34;
            _context2.t1 = _context2["catch"](19);
            console.log("---getChannelDataErrFinish---" + (0, _util.stringifyError)(_context2.t1));
            throw _context2.t1;

          case 38:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2, null, [[0, 12], [19, 34]]);
  }));
  return _getChannelData.apply(this, arguments);
}

function getModuleData(_x3, _x4) {
  return _getModuleData.apply(this, arguments);
}

function _getModuleData() {
  _getModuleData = _asyncToGenerator(
  /*#__PURE__*/
  regeneratorRuntime.mark(function _callee3(param, _ref) {
    var index, needCheckAttention, moduleData, data, type, _Store$__vn$data2, listIndex, cellType, originalListIndex, allList, hasDiffrent, _Store$__vn$data3;

    return regeneratorRuntime.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            index = _ref.index, needCheckAttention = _ref.needCheckAttention;
            console.log("---getModuleData---".concat(param));
            _context3.next = 4;
            return channelService.getChannelData(_extends(param, {
              channelId: _index.Store.channelId,
              cmdid: 0x61fa,
              vappid: '20960712',
              vsecret: '79f4377adb67664f12c73289da48d759ced2d31d19b7ac19',
              dataKey: param.dataKey
            }));

          case 4:
            moduleData = _context3.sent;

            if (!(moduleData.data && moduleData.data.pageContext === '-1')) {
              _context3.next = 8;
              break;
            }

            console.log('----getModuleDataErr-----(-1)');
            throw new Error('----getModuleDataErr-----(-1)');

          case 8:
            console.log("---moduleDataListlengh:".concat(moduleData.data && moduleData.data.modList && moduleData.data.modList[0].list && moduleData.data.modList[0].list.length));

            if (!(moduleData.data && moduleData.data.modList && moduleData.data.modList[0].list && moduleData.data.modList[0].list.length > 0)) {
              _context3.next = 37;
              break;
            }

            data = moduleData.data.modList[0];
            data.list = data.list.map(_util2.processPosterData);

            if (!needCheckAttention) {
              _context3.next = 16;
              break;
            }

            _context3.next = 15;
            return (0, _processChannelData.processModuleListData)(data.list);

          case 15:
            data.list = _context3.sent;

          case 16:
            type = _index.Store.__vn.data.query("listData[".concat(index, "].sectionType"));
            console.log("--sectionType--".concat(type));

            if (!(type === 'exchangeComponent')) {
              _context3.next = 35;
              break;
            }

            _index.Store.__vn.data.update("listData[".concat(index, "].cells[0].cmsData.seq_num"), data.cms_data.seq_num);

            _index.Store.__vn.data.update("listData[".concat(index, "].cells[0].cmsData.shake_datakey"), data.cms_data.shake_datakey);

            listIndex = index - 1;
            cellType = _index.Store.__vn.data.query("listData[".concat(listIndex, "].cells[0].type"));
            originalListIndex = _index.Store.__vn.data.query("listData[".concat(index, "].cells[0].shake.listIndex"));
            data.list = data.list.map(function (item) {
              return (0, _util2.processCellTypeData)(cellType, item);
            });
            allList = _index.Store.__vn.data.query("listData[".concat(listIndex, "].allList"));
            hasDiffrent = data.list.some(function (item, index) {
              return item.data.itemId !== allList[index].data.itemId;
            });

            if (hasDiffrent) {
              _context3.next = 30;
              break;
            }

            moduleData.data.pageContext = 'page=-1';
            return _context3.abrupt("return", moduleData);

          case 30:
            console.log("--originalListIndex--".concat(originalListIndex));

            (_Store$__vn$data2 = _index.Store.__vn.data).append.apply(_Store$__vn$data2, ["listData[".concat(listIndex, "].allList")].concat(_toConsumableArray(data.list)));

            _index.Store.listData[originalListIndex].allList = _index.Store.__vn.data.query("listData[".concat(listIndex, "].allList"));
            _context3.next = 37;
            break;

          case 35:
            (_Store$__vn$data3 = _index.Store.__vn.data).append.apply(_Store$__vn$data3, ["listData[".concat(index, "].cells.list")].concat(_toConsumableArray(data.list)));

            _index.Store.__vn.data.update("listData[".concat(index, "].cms_data.seq_num"), data.cms_data.seq_num);

          case 37:
            return _context3.abrupt("return", moduleData);

          case 38:
          case "end":
            return _context3.stop();
        }
      }
    }, _callee3);
  }));
  return _getModuleData.apply(this, arguments);
}