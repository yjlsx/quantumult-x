"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getDetainTip = getDetainTip;
exports.getPromotion = getPromotion;

var _index = require("../index");

var channelService = _interopRequireWildcard(require("../../service/channelService"));

var _configService = require("../../service/configService");

var _util = require("../../util/util");

var atom = _interopRequireWildcard(require("../../util/atom"));

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = Object.defineProperty && Object.getOwnPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : {}; if (desc.get || desc.set) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } } newObj.default = obj; return newObj; } }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

/**
 * 获取个性化推荐标签弹层
 */
function getDetainTip() {
  return _getDetainTip.apply(this, arguments);
}
/**
 * 获取个人信息条广告位
 * @param {object} param
 */


function _getDetainTip() {
  _getDetainTip = _asyncToGenerator(
  /*#__PURE__*/
  regeneratorRuntime.mark(function _callee() {
    var detainTip;
    return regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.prev = 0;
            _context.next = 3;
            return channelService.getDetainTip();

          case 3:
            detainTip = _context.sent;
            detainTip.vr_report_banner_rmnd_btm = {
              content_id: detainTip.info.cid
            };
            _index.Store.detainTip = detainTip;

            _index.Store.__vn.data.update('detainTip', detainTip);

            return _context.abrupt("return", detainTip);

          case 10:
            _context.prev = 10;
            _context.t0 = _context["catch"](0);
            console.log('---getDetainTipErr---' + JSON.stringify(_context.t0));
            return _context.abrupt("return", {});

          case 14:
          case "end":
            return _context.stop();
        }
      }
    }, _callee, null, [[0, 10]]);
  }));
  return _getDetainTip.apply(this, arguments);
}

function getPromotion(_x) {
  return _getPromotion.apply(this, arguments);
}
/**
 * 请求启明推广位
 * @param {*} qimingSwitch
 */


function _getPromotion() {
  _getPromotion = _asyncToGenerator(
  /*#__PURE__*/
  regeneratorRuntime.mark(function _callee2(_ref) {
    var platform, version, promotion, qimingSwitch;
    return regeneratorRuntime.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            platform = _ref.platform, version = _ref.version;
            _context2.prev = 1;
            _context2.next = 4;
            return (0, _configService.getQiMingSwitch)();

          case 4:
            qimingSwitch = _context2.sent;
            console.log(qimingSwitch); // todo 玲珑下线的时候 需要将版本判断挪到getQiMingParam内

            if (!(qimingSwitch && qimingSwitch.data.is_use_qiming && (0, _util.compareVersion)(_index.Store.appInfo.version, '8.2.35'))) {
              _context2.next = 13;
              break;
            }

            console.log('-----getQiMingPromotion------');
            _context2.next = 10;
            return getQiMingPromotion(qimingSwitch);

          case 10:
            promotion = _context2.sent;
            _context2.next = 17;
            break;

          case 13:
            console.log('-----getLingLongPromotion------');
            _context2.next = 16;
            return getLingLongPromotion({
              platform: platform,
              version: version
            });

          case 16:
            promotion = _context2.sent;

          case 17:
            console.log(promotion);
            _index.Store.promotion = promotion;

            _index.Store.__vn.data.update('promotion', promotion);

            return _context2.abrupt("return", promotion);

          case 23:
            _context2.prev = 23;
            _context2.t0 = _context2["catch"](1);

          case 25:
            _index.Store.promotion = null;

            _index.Store.__vn.data.update('promotion', null);

            return _context2.abrupt("return", promotion);

          case 28:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2, null, [[1, 23]]);
  }));
  return _getPromotion.apply(this, arguments);
}

function getQiMingPromotion(_x2) {
  return _getQiMingPromotion.apply(this, arguments);
}
/**
 * 启明推广位参数获取
 * @param {*} qimingSwitch
 */


function _getQiMingPromotion() {
  _getQiMingPromotion = _asyncToGenerator(
  /*#__PURE__*/
  regeneratorRuntime.mark(function _callee3(qimingSwitch) {
    var resId, _ref3, param, header, res, promotion;

    return regeneratorRuntime.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.prev = 0;
            resId = qimingSwitch.data.res_id;
            _context3.next = 4;
            return getQiMingParam(qimingSwitch);

          case 4:
            _ref3 = _context3.sent;
            param = _ref3.param;
            header = _ref3.header;
            _context3.next = 9;
            return channelService.getQiMingPromotion(param, header);

          case 9:
            res = _context3.sent;

            if (!(res && res.Mod2Items && res.Mod2Items[resId] && Array.isArray(res.Mod2Items[resId].Items))) {
              _context3.next = 18;
              break;
            }

            res = res.Mod2Items[resId].Items[0];
            console.log(res);
            promotion = {
              configId: '',
              magicId: res && res.BannerItem.report_dict.f_cubeid || '',
              online: true,
              picBkg: res && res.DisplayItem.bg_image_url,
              url: res && res.BannerItem.action_info.url,
              ptag: res && res.BannerItem.report_dict.vip_id || 'ad.userinfo',
              res_id: resId,
              task_id: res && res.BannerItem.mark_info.task_id,
              data_key: res && res.BannerItem.mark_info.data_key
            };
            promotion.vr_report_detail = _extends({
              mod_title: '活动页按钮',
              url: res.BannerItem.action_info.url
            }, _index.Store.vr_report_default, res.BannerItem.report_dict);
            console.log(promotion); // 添加任务

            atom.invoke('addResourceTask', {
              type: 'exposure',
              user_id: _index.Store.deviceInfo.omgid || '',
              res_id: resId,
              task_id: res && res.BannerItem.mark_info.task_id || '',
              data_key: res && res.BannerItem.mark_info.data_key || '',
              time: Date.now() + ''
            });
            return _context3.abrupt("return", promotion);

          case 18:
            console.log('---getQiMingPromotionDataErr---' + (0, _util.stringifyError)(res));
            return _context3.abrupt("return", {});

          case 22:
            _context3.prev = 22;
            _context3.t0 = _context3["catch"](0);
            console.log('---getQiMingPromotionErr---' + (0, _util.stringifyError)(_context3.t0));
            return _context3.abrupt("return", {});

          case 26:
          case "end":
            return _context3.stop();
        }
      }
    }, _callee3, null, [[0, 22]]);
  }));
  return _getQiMingPromotion.apply(this, arguments);
}

function getQiMingParam(_x3) {
  return _getQiMingParam.apply(this, arguments);
}
/**
 * 请求玲珑推广位
 * @param {*} param0
 */


function _getQiMingParam() {
  _getQiMingParam = _asyncToGenerator(
  /*#__PURE__*/
  regeneratorRuntime.mark(function _callee4(qimingSwitch) {
    var Source, resId, exposeDataKey, clickDataKey;
    return regeneratorRuntime.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            Source = +qimingSwitch.data.Source || 1001;
            resId = qimingSwitch.data.res_id || '1601';
            _context4.prev = 2;
            _context4.next = 5;
            return atom.invoke('queryResourceTask', {
              type: 'exposure',
              user_id: _index.Store.deviceInfo.omgid || '',
              res_id_list: [resId]
            }, {
              timeout: 3000
            });

          case 5:
            exposeDataKey = _context4.sent;
            _context4.next = 8;
            return atom.invoke('queryResourceTask', {
              type: 'click',
              user_id: _index.Store._cookie.vuserid || _index.Store._cookie.vqq_vuserid || '',
              res_id_list: [resId]
            }, {
              timeout: 3000
            });

          case 8:
            clickDataKey = _context4.sent;
            _context4.next = 14;
            break;

          case 11:
            _context4.prev = 11;
            _context4.t0 = _context4["catch"](2);
            console.log('---queryResourceTaskErr---' + (0, _util.stringifyError)(_context4.t0));

          case 14:
            console.log("---exposeDataKey---".concat(exposeDataKey));
            console.log("---clickDataKey---".concat(JSON.stringify(clickDataKey)));
            return _context4.abrupt("return", {
              param: {
                Location: {
                  Source: Source,
                  CmsChannelId: +_index.Store.channelId
                },
                User: {
                  IsVip: _index.Store.payVip.isRealVip
                },
                Session: {
                  ExposureDataKey: encodeURIComponent(exposeDataKey.hasOwnProperty('result') ? exposeDataKey.result : exposeDataKey || ''),
                  ClickDataKey: encodeURIComponent(clickDataKey.hasOwnProperty('result') ? clickDataKey.result : clickDataKey || '')
                }
              },
              header: {
                'Custom-Devices': (0, _util.createKVString)({
                  omg_id: _index.Store.deviceInfo.omgid || '',
                  guid: _index.Store.deviceInfo.guid || '',
                  device_id: _index.Store.deviceInfo.deviceId || ''
                }, ';'),
                'Custom-Versions': (0, _util.createKVString)({
                  platform: _index.Store.systemInfo.isIpad ? 4 : _index.Store.systemInfo.isIos ? 5 : 3,
                  version_name: _index.Store.appInfo.version || '',
                  channel_id: _index.Store.appInfo.channelID ? '' + _index.Store.appInfo.channelID : '',
                  platform_version: _index.Store.systemInfo.isIos ? _index.Store.systemInfo.iosVersion : ''
                }, ';'),
                'Custom-Bucket': (0, _util.createKVString)({
                  bucket_id: _index.Store.appInfo.bucketId || ''
                }, ';')
              }
            });

          case 17:
          case "end":
            return _context4.stop();
        }
      }
    }, _callee4, null, [[2, 11]]);
  }));
  return _getQiMingParam.apply(this, arguments);
}

function getLingLongPromotion(_x4) {
  return _getLingLongPromotion.apply(this, arguments);
}

function _getLingLongPromotion() {
  _getLingLongPromotion = _asyncToGenerator(
  /*#__PURE__*/
  regeneratorRuntime.mark(function _callee5(_ref2) {
    var platform, version, promotion, date;
    return regeneratorRuntime.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            platform = _ref2.platform, version = _ref2.version;
            _context5.prev = 1;
            _context5.next = 4;
            return channelService.getPromotion({
              platform: platform === 'ios' ? 7 : 8,
              version: version
            });

          case 4:
            promotion = _context5.sent;

            if (!(promotion.posList && promotion.posList[0] && promotion.posList[0].confData && promotion.posList[0].confData[0])) {
              _context5.next = 11;
              break;
            }

            promotion = promotion.posList[0].confData[0];
            date = new Date();
            promotion.online = date > new Date(promotion.begTime.replace(/-/g, '/')) && date < new Date(promotion.endTime.replace(/-/g, '/'));
            promotion.vr_report_detail = _extends({
              mod_title: '活动页按钮',
              url: promotion.url,
              f_cubeid: promotion.magicId,
              f_item: promotion.configId,
              vip_id: promotion.ptag,
              business: 'hollywood',
              ptag: 'ad.userinfo'
            }, _index.Store.vr_report_default);
            return _context5.abrupt("return", promotion);

          case 11:
            console.log('---getLingLongPromotionDataErr---' + JSON.stringify(promotion));
            return _context5.abrupt("return", {});

          case 15:
            _context5.prev = 15;
            _context5.t0 = _context5["catch"](1);
            console.log('---getLingLongPromotionErr---' + (0, _util.stringifyError)(_context5.t0));
            return _context5.abrupt("return", {});

          case 19:
          case "end":
            return _context5.stop();
        }
      }
    }, _callee5, null, [[1, 15]]);
  }));
  return _getLingLongPromotion.apply(this, arguments);
}