"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getPayVip = getPayVip;
exports.getScore = getScore;
exports.getAvatarPendant = getAvatarPendant;
exports.getAppConfig = getAppConfig;

var _index = require("../index");

var atom = _interopRequireWildcard(require("../../util/atom"));

var userInfoService = _interopRequireWildcard(require("../../service/userInfoService"));

var configService = _interopRequireWildcard(require("../../service/configService"));

var _processData = require("../processData/processData");

var _cacheProcessor = require("../../util/cacheProcessor");

var _util = require("../../util/util");

var _cache = require("../../util/cache");

var _functionProc = _interopRequireDefault(require("../../util/functionProc"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = Object.defineProperty && Object.getOwnPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : {}; if (desc.get || desc.set) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } } newObj.default = obj; return newObj; } }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

var PROCS = {};

var updateData = function updateData(key, data) {
  if (data) {
    _index.Store[key] = data;

    _index.Store.__vn.data.update(key, data);
  }
};
/**
 * 获取用户会员信息
 */


function getPayVip() {
  return _getPayVip.apply(this, arguments);
}
/**
 * 获取用户积分信息
 */


function _getPayVip() {
  _getPayVip = _asyncToGenerator(
  /*#__PURE__*/
  regeneratorRuntime.mark(function _callee2() {
    var options;
    return regeneratorRuntime.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            options = {
              state: _index.Store.networkState.state,
              key: 'payVip',
              updateData: updateData
            };

            if (!PROCS.payVip) {
              PROCS.payVip = new _functionProc.default(options);
              PROCS.payVip.addProc(_cacheProcessor.firstGetFromCache, 'firstGetFromCache');
              PROCS.payVip.addProc(
              /*#__PURE__*/
              function () {
                var _ref = _asyncToGenerator(
                /*#__PURE__*/
                regeneratorRuntime.mark(function _callee(options) {
                  var payVip;
                  return regeneratorRuntime.wrap(function _callee$(_context) {
                    while (1) {
                      switch (_context.prev = _context.next) {
                        case 0:
                          _context.prev = 0;
                          _context.next = 3;
                          return atom.invoke('getPayVip');

                        case 3:
                          payVip = _context.sent;
                          payVip = (0, _processData.processPayVip)(payVip);
                          console.log('---afterProcessPayVip---' + JSON.stringify(payVip));
                          updateData('payVip', payVip);
                          (0, _cache.setCacheWithLogin)('payVip', payVip);
                          _index.Store.payVip = payVip;
                          return _context.abrupt("return", payVip);

                        case 12:
                          _context.prev = 12;
                          _context.t0 = _context["catch"](0);
                          payVip = options.data;

                          if (payVip && !payVip.hasOwnProperty('beginTime')) {
                            atom.invoke('toast', {
                              content: '获取会员信息失败'
                            });
                          }

                          console.log('---getPayVipErr---' + (0, _util.stringifyError)(_context.t0));

                        case 17:
                        case "end":
                          return _context.stop();
                      }
                    }
                  }, _callee, null, [[0, 12]]);
                }));

                return function (_x) {
                  return _ref.apply(this, arguments);
                };
              }(), 'getPayVip');
            }

            _context2.next = 4;
            return PROCS.payVip.run(options);

          case 4:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2);
  }));
  return _getPayVip.apply(this, arguments);
}

function getScore() {
  return _getScore.apply(this, arguments);
}
/**
 * 获取用户个性化头像框
 */


function _getScore() {
  _getScore = _asyncToGenerator(
  /*#__PURE__*/
  regeneratorRuntime.mark(function _callee4() {
    var options;
    return regeneratorRuntime.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            options = {
              state: _index.Store.networkState.state,
              key: 'getScore',
              updateData: updateData
            };

            if (!PROCS.getScore) {
              PROCS.getScore = new _functionProc.default(options);
              PROCS.getScore.addProc(_cacheProcessor.firstGetFromCache, 'firstGetFromCache');
              PROCS.getScore.addProc(
              /*#__PURE__*/
              _asyncToGenerator(
              /*#__PURE__*/
              regeneratorRuntime.mark(function _callee3() {
                var score;
                return regeneratorRuntime.wrap(function _callee3$(_context3) {
                  while (1) {
                    switch (_context3.prev = _context3.next) {
                      case 0:
                        _context3.prev = 0;
                        _context3.next = 3;
                        return userInfoService.getScore();

                      case 3:
                        score = _context3.sent;
                        updateData('score', score);
                        (0, _cache.setCacheWithLogin)('score', score);
                        console.log('---getScore---' + JSON.stringify(score));
                        return _context3.abrupt("return", score);

                      case 10:
                        _context3.prev = 10;
                        _context3.t0 = _context3["catch"](0);
                        _context3.next = 14;
                        return (0, _cache.getCacheWithLogin)('payVip');

                      case 14:
                        score = _context3.sent;

                        if (!score.hasOwnProperty('vip_score_total')) {
                          atom.invoke('toast', {
                            content: '获取积分信息失败'
                          });
                        }

                        console.log('---getScoreErr---' + (0, _util.stringifyError)(_context3.t0));

                      case 17:
                      case "end":
                        return _context3.stop();
                    }
                  }
                }, _callee3, null, [[0, 10]]);
              })));
            }

            _context4.next = 4;
            return PROCS.getScore.run(options);

          case 4:
          case "end":
            return _context4.stop();
        }
      }
    }, _callee4);
  }));
  return _getScore.apply(this, arguments);
}

function getAvatarPendant() {
  return _getAvatarPendant.apply(this, arguments);
}

function _getAvatarPendant() {
  _getAvatarPendant = _asyncToGenerator(
  /*#__PURE__*/
  regeneratorRuntime.mark(function _callee5() {
    var res, data, pic;
    return regeneratorRuntime.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            if (_index.Store.isLogin) {
              _context5.next = 4;
              break;
            }

            // 未登录直接返回''
            _index.Store.avatarPendant = '';

            _index.Store.__vn.data.update('avatarPendant', '');

            return _context5.abrupt("return", '');

          case 4:
            _context5.prev = 4;
            _context5.next = 7;
            return userInfoService.getAvatarPendant();

          case 7:
            res = _context5.sent;
            data = res.posList[0];

            if (!(data.code === 0)) {
              _context5.next = 14;
              break;
            }

            pic = data.confData[0].pic_channel_140x140;
            _index.Store.avatarPendant = pic;

            _index.Store.__vn.data.update('avatarPendant', pic);

            return _context5.abrupt("return", pic);

          case 14:
            console.log('---getAvatarPendantErr---' + JSON.stringify(data));
            _context5.next = 20;
            break;

          case 17:
            _context5.prev = 17;
            _context5.t0 = _context5["catch"](4);
            console.log('---getAvatarPendantErr---' + (0, _util.stringifyError)(_context5.t0));

          case 20:
            _index.Store.avatarPendant = '';

            _index.Store.__vn.data.update('avatarPendant', '');

            return _context5.abrupt("return", '');

          case 23:
          case "end":
            return _context5.stop();
        }
      }
    }, _callee5, null, [[4, 17]]);
  }));
  return _getAvatarPendant.apply(this, arguments);
}

function getAppConfig() {
  return _getAppConfig.apply(this, arguments);
}

function _getAppConfig() {
  _getAppConfig = _asyncToGenerator(
  /*#__PURE__*/
  regeneratorRuntime.mark(function _callee7() {
    var options, isBaBa;
    return regeneratorRuntime.wrap(function _callee7$(_context7) {
      while (1) {
        switch (_context7.prev = _context7.next) {
          case 0:
            if (!(_index.Store.appInfo && (0, _util.compareVersion)(_index.Store.appInfo.version, '7.9.0') && _index.Store.systemInfo.isIos)) {
              _context7.next = 7;
              break;
            }

            options = {
              state: _index.Store.networkState.state,
              key: 'appConfig',
              updateData: updateData
            };
            isBaBa = false;

            if (!PROCS.appConfig) {
              PROCS.appConfig = new _functionProc.default(options);
              PROCS.appConfig.addProc(_cacheProcessor.firstGetFromCache, 'firstGetFromCache');
              PROCS.appConfig.addProc(
              /*#__PURE__*/
              _asyncToGenerator(
              /*#__PURE__*/
              regeneratorRuntime.mark(function _callee6() {
                var res;
                return regeneratorRuntime.wrap(function _callee6$(_context6) {
                  while (1) {
                    switch (_context6.prev = _context6.next) {
                      case 0:
                        _context6.prev = 0;
                        _context6.next = 3;
                        return configService.getBaBa({
                          env: 'production',
                          version: _index.Store.appInfo.version
                        });

                      case 3:
                        res = _context6.sent;
                        console.log("--getAppConfig--".concat(JSON.stringify(res)));

                        if (res.code === 200 && res.data && Array.isArray(res.data) && res.data.length > 0) {
                          isBaBa = true;
                        }

                        updateData('isBaBa', {
                          isBaBa: isBaBa,
                          showBtn: true
                        });
                        (0, _cache.setCache)('isBaBa', {
                          isBaBa: isBaBa,
                          showBtn: true
                        });
                        return _context6.abrupt("return", isBaBa);

                      case 11:
                        _context6.prev = 11;
                        _context6.t0 = _context6["catch"](0);
                        console.log("--getAppConfigErr--".concat((0, _util.stringifyError)(_context6.t0)));
                        _context6.next = 16;
                        return (0, _cache.getCache)('isBaBa');

                      case 16:
                        isBaBa = _context6.sent;
                        updateData('isBaBa', {
                          isBaBa: false,
                          showBtn: true
                        });
                        (0, _util.stringifyError)(_context6.t0);

                      case 19:
                      case "end":
                        return _context6.stop();
                    }
                  }
                }, _callee6, null, [[0, 11]]);
              })), 'getPayVip');
            }

            _context7.next = 6;
            return PROCS.appConfig.run(options);

          case 6:
            return _context7.abrupt("return");

          case 7:
            updateData('isBaBa', {
              isBaBa: false,
              showBtn: true
            });

          case 8:
          case "end":
            return _context7.stop();
        }
      }
    }, _callee7);
  }));
  return _getAppConfig.apply(this, arguments);
}