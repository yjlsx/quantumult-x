"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ModuleName = exports.Month = exports.activityBarNum = exports.starNum = exports.leftPicNum = exports.labelNum = exports.horMaxNum = exports.UISizeMap = exports.UISizeMax = exports.UISizeHuge = exports.UISizeLarge = exports.UISizeRegular = void 0;

var _UISizeMap, _horMaxNum, _labelNum, _leftPicNum, _starNum, _activityBarNum;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var UISizeRegular = 'regular';
exports.UISizeRegular = UISizeRegular;
var UISizeLarge = 'large';
exports.UISizeLarge = UISizeLarge;
var UISizeHuge = 'huge';
exports.UISizeHuge = UISizeHuge;
var UISizeMax = 'max'; // 1 =phone的尺寸 4=折叠屏尺寸 2=pad尺寸 5=pad pro尺寸

exports.UISizeMax = UISizeMax;
var UISizeMap = (_UISizeMap = {}, _defineProperty(_UISizeMap, UISizeRegular, 1), _defineProperty(_UISizeMap, UISizeLarge, 4), _defineProperty(_UISizeMap, UISizeHuge, 2), _defineProperty(_UISizeMap, UISizeMax, 5), _UISizeMap); // 各机型下横图平铺数量

exports.UISizeMap = UISizeMap;
var horMaxNum = (_horMaxNum = {}, _defineProperty(_horMaxNum, UISizeRegular, 2), _defineProperty(_horMaxNum, UISizeLarge, 3), _defineProperty(_horMaxNum, UISizeHuge, 4), _defineProperty(_horMaxNum, UISizeMax, 5), _horMaxNum); // 各机型下标签的数量

exports.horMaxNum = horMaxNum;
var labelNum = (_labelNum = {}, _defineProperty(_labelNum, UISizeRegular, 3), _defineProperty(_labelNum, UISizeLarge, 5), _defineProperty(_labelNum, UISizeHuge, 3), _defineProperty(_labelNum, UISizeMax, 5), _labelNum); // 各机型下左图右文数量

exports.labelNum = labelNum;
var leftPicNum = (_leftPicNum = {}, _defineProperty(_leftPicNum, UISizeRegular, 3), _defineProperty(_leftPicNum, UISizeLarge, 6), _defineProperty(_leftPicNum, UISizeHuge, 6), _defineProperty(_leftPicNum, UISizeMax, 6), _leftPicNum); // 明星数量

exports.leftPicNum = leftPicNum;
var starNum = (_starNum = {}, _defineProperty(_starNum, UISizeRegular, 4), _defineProperty(_starNum, UISizeLarge, 6), _defineProperty(_starNum, UISizeHuge, 6), _defineProperty(_starNum, UISizeMax, 6), _starNum); // 大黄条数量

exports.starNum = starNum;
var activityBarNum = (_activityBarNum = {}, _defineProperty(_activityBarNum, UISizeRegular, 1), _defineProperty(_activityBarNum, UISizeLarge, 1), _defineProperty(_activityBarNum, UISizeHuge, 2), _defineProperty(_activityBarNum, UISizeMax, 2), _activityBarNum);
exports.activityBarNum = activityBarNum;
var Month = {
  0: '一月',
  1: '二月',
  2: '三月',
  3: '四月',
  4: '五月',
  5: '六月',
  6: '七月',
  7: '八月',
  8: '九月',
  9: '十月',
  10: '十一月',
  11: '十二月'
};
exports.Month = Month;
var ModuleName = {
  'type_62': '焦点图模块',
  'type_30066': '今日推荐模块',
  'type_30041': '横滑模块',
  'type_30014': '平铺模块',
  'type_235': '福利社模块',
  'type_58': '即将上映模块',
  'type_30062': '好友模块',
  'type_30063': '大黄条模块',
  'type_30060': '明星模块',
  'type_30061': '影集模块',
  'type_30065': '兴趣标签模块',
  'type_30069': '左图右文模块',
  'type_273': '推广位模块'
};
exports.ModuleName = ModuleName;