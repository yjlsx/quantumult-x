"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.moduleLoadNext = moduleLoadNext;

var _action = require("./action.js");

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function moduleLoadNext(_x, _x2) {
  return _moduleLoadNext.apply(this, arguments);
}

function _moduleLoadNext() {
  _moduleLoadNext = _asyncToGenerator(
  /*#__PURE__*/
  regeneratorRuntime.mark(function _callee(param, loadNextFinish) {
    var index, cmsData, moduleData;
    return regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            index = param.index;
            cmsData = param.cmsData;
            console.log("---moduleLoadNext---seqNumReq:".concat(cmsData.seq_num, "--dataKey:").concat(cmsData.shake_datakey));
            _context.prev = 3;
            _context.next = 6;
            return _action.storeAction.getModuleData({
              seqNum: cmsData.seq_num,
              dataKey: cmsData.shake_datakey,
              modNum: 1
            }, {
              index: index,
              needCheckAttention: param.needCheckAttention
            });

          case 6:
            moduleData = _context.sent;

            if (moduleData.data && moduleData.data.pageContext === 'page=-1' || !moduleData.data) {
              console.log('---getModuleDataNextFinish---');
              loadNextFinish(false, index);
            } else {
              loadNextFinish(true, index);
            }

            _context.next = 16;
            break;

          case 10:
            _context.prev = 10;
            _context.t0 = _context["catch"](3);
            console.log('---getModuleDataError---');
            console.log(_context.t0);
            console.log(JSON.stringify(_context.t0));
            loadNextFinish(false, index);

          case 16:
          case "end":
            return _context.stop();
        }
      }
    }, _callee, null, [[3, 10]]);
  }));
  return _moduleLoadNext.apply(this, arguments);
}