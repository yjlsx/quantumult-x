"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.storeAction = void 0;

var _util = require("../util/util");

var _frontAction = require("./action/frontAction");

var _userInfoServiceAction = require("./action/userInfoServiceAction");

var _channelServiceAction = require("./action/channelServiceAction");

var _moduleDataAction = require("./action/moduleDataAction");

var _processChannelData = require("./processData/processChannelData");

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

/**
   * 刷新用户信息的操作
   */
function refreshUserData() {
  return _refreshUserData.apply(this, arguments);
}

function _refreshUserData() {
  _refreshUserData = _asyncToGenerator(
  /*#__PURE__*/
  regeneratorRuntime.mark(function _callee() {
    return regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return (0, _frontAction.checkLogin)();

          case 2:
            _context.next = 4;
            return (0, _frontAction.getCookie)();

          case 4:
            (0, _userInfoServiceAction.getPayVip)();

          case 5:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));
  return _refreshUserData.apply(this, arguments);
}

var storeAction = {
  getModuleData: _moduleDataAction.getModuleData,
  getCookie: _frontAction.getCookie,
  getSystemInfo: _frontAction.getSystemInfo,
  getAppInfo: _frontAction.getAppInfo,
  getPullRefreshData: _frontAction.getPullRefreshData,
  getScreenSize: _frontAction.getScreenSize,
  checkLogin: _frontAction.checkLogin,
  getPayVip: _userInfoServiceAction.getPayVip,
  getScore: _userInfoServiceAction.getScore,
  getAvatarPendant: _userInfoServiceAction.getAvatarPendant,
  getDetainTip: _channelServiceAction.getDetainTip,
  getPromotion: _channelServiceAction.getPromotion,
  getChannelData: _moduleDataAction.getChannelData,
  getChannelDataFromCache: _moduleDataAction.getChannelDataFromCache,
  refreshUserData: refreshUserData,
  reportJceLoad: _util.reportJceLoad,
  refreshAllChannelData: _processChannelData.refreshAllChannelData,
  getAppConfig: _userInfoServiceAction.getAppConfig
};
exports.storeAction = storeAction;