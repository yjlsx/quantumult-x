"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Store = void 0;
window.Promise = require('/lib/es6').Promise;
var Store = {}; // 下拉刷新图协议

exports.Store = Store;
Store.pullRefreshData = {}; // 上报事件定义

Store.reportEvent = {
  posterExpose: 'video_jce_poster_exposure',
  posterClick: 'video_jce_action_click',
  vvClick: 'boss_cmd_vv',
  buttonExpose: 'common_button_item_exposure',
  buttonClick: 'common_button_item_click',
  pageExpose: 'video_jce_page_view',
  channelExpose: 'home_channel_page_show',
  pageStay: 'video_jce_page_view_stay_time' // 初始化没有点击事件

};
Store.hasClick = false;
Store.listData = [];