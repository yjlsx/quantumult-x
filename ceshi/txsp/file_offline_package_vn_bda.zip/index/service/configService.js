"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getBaBa = getBaBa;
exports.getQiMingSwitch = getQiMingSwitch;

var _vnRequest = _interopRequireDefault(require("../util/vnRequest"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var wujiCgi = 'https://wuji.video.qq.com/fcgi-bin/wuji';
var config = {
  env: {
    production: {
      appid: '1000674',
      appkey: '400c78b960f849f9b22d6ad4d9518c11'
    },
    test: {
      appid: '1000675',
      appkey: 'd760f2b61c9c4fe1b0413551a6e588a7'
    }
  }
};

function getBaBa(_ref) {
  var _ref$env = _ref.env,
      env = _ref$env === void 0 ? 'production' : _ref$env,
      version = _ref.version;
  var _config$env$env = config.env[env],
      appid = _config$env$env.appid,
      appkey = _config$env$env.appkey;
  return (0, _vnRequest.default)(wujiCgi, {
    appid: appid,
    appkey: appkey,
    filter: "v=".concat(version, "&r=true&p=iphone")
  });
}

function getQiMingSwitch() {
  return (0, _vnRequest.default)('https://v.qq.com/cache/wuji/object/5f1e9ec2abcfa80738494dd5?appid=vip&schemaid=vn_user_activity_switch&schemakey=abf3c59d58464f11b3a9381ca80a8542');
}