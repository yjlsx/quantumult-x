"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getChannelData = getChannelData;
exports.getDetainTip = getDetainTip;
exports.getPromotion = getPromotion;
exports.getQiMingPromotion = getQiMingPromotion;

var _vnRequest = _interopRequireDefault(require("../util/vnRequest"));

var atom = _interopRequireWildcard(require("../util/atom"));

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = Object.defineProperty && Object.getOwnPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : {}; if (desc.get || desc.set) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var vipCgi = 'https://vip.video.qq.com/fcgi-bin/comm_cgi';
var Timeout = 32000;
/**
 * 通过jsapi获取频道数据
 * @param {object} param0
 */

function getChannelData() {
  var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      _ref$pageContext = _ref.pageContext,
      pageContext = _ref$pageContext === void 0 ? '' : _ref$pageContext,
      _ref$modNum = _ref.modNum,
      modNum = _ref$modNum === void 0 ? '4' : _ref$modNum,
      _ref$channelId = _ref.channelId,
      channelId = _ref$channelId === void 0 ? '100137' : _ref$channelId,
      _ref$seqNum = _ref.seqNum,
      seqNum = _ref$seqNum === void 0 ? '' : _ref$seqNum,
      _ref$expansion = _ref.expansion,
      expansion = _ref$expansion === void 0 ? 'device_type=1' : _ref$expansion,
      _ref$cmdid = _ref.cmdid,
      cmdid = _ref$cmdid === void 0 ? 0x5c73 : _ref$cmdid,
      vappid = _ref.vappid,
      vsecret = _ref.vsecret,
      dataKey = _ref.dataKey;

  var data = {
    cmdid: cmdid,
    requestjson: JSON.stringify({
      vappid: vappid,
      vsecret: vsecret,
      channelId: channelId,
      modNum: modNum + '',
      pageContext: pageContext || '',
      seqNum: seqNum || '',
      expansion: expansion,
      dataKey: dataKey || ''
    })
  };

  if (typeof VipVnJsBridge !== 'undefined' && VipVnJsBridge.getPageData) {
    return new Promise(function (resolve, reject) {
      console.log("----getPageData----seqNum:".concat(seqNum, "---pageContextreq\"").concat(pageContext, "-expansionReq:").concat(expansion, "--cmdid:0x").concat(cmdid.toString(16)));
      var finish = false;
      setTimeout(function () {
        if (!finish) {
          console.log('---getPageDataTimeOut---');
          return reject(new Error('getPageDataTimeOut'));
        }
      }, Timeout);
      VipVnJsBridge.getPageData(data, function (params) {
        console.log("----getPageDataCallback----");
        finish = true;

        try {
          return resolve(JSON.parse(params));
        } catch (e) {
          console.log("----PageDataparseErr----");
          console.log(params);
          return reject(e);
        }
      });
    });
  } else {
    return atom.invoke('getPageData', data, {
      timeout: Timeout
    });
  }
}
/**
 * 获取个性化推荐弹窗
 */


function getDetainTip() {
  return (0, _vnRequest.default)(vipCgi, {
    name: 'detain_tips',
    otype: 'xjson',
    cmd: 200,
    js_trans: 1,
    json_req: '%7B%220_numeric_str%22%3a%220%22%7D'
  });
}
/**
 * 获取用户信息推广位
 * @param {object}} param
 */


function getPromotion(_ref2) {
  var _ref2$platform = _ref2.platform,
      platform = _ref2$platform === void 0 ? 7 : _ref2$platform,
      version = _ref2.version;
  return (0, _vnRequest.default)(vipCgi, {
    name: 'spp_VipActConf_V2',
    otype: 'xjson',
    cmd: 2,
    posId: 44,
    platform: platform,
    version: version
  });
}

function getQiMingPromotion(param, header) {
  console.log("---getQiMingPromotion---".concat(JSON.stringify(param)));
  return (0, _vnRequest.default)('https://vip.video.qq.com/rpc/trpc.promotion.adapter.adapter/GetVipResourceItems', {
    rpc_data: JSON.stringify(param)
  }, 5000, header);
}