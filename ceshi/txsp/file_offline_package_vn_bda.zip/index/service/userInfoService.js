"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getPayVip = getPayVip;
exports.getScore = getScore;
exports.getAvatarPendant = getAvatarPendant;

var _vnRequest = _interopRequireDefault(require("../util/vnRequest"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var vipCgi = 'https://vip.video.qq.com/fcgi-bin/comm_cgi';
var payVipCgi = 'https://pay.video.qq.com/fcgi-bin/payvip';
var avatarPendantCgi = 'https://vip.video.qq.com/fcgi-bin/comm_cgi';
/**
 * 获取会员信息
 */

function getPayVip() {
  return (0, _vnRequest.default)(payVipCgi, {
    otype: 'json',
    getannual: 1,
    geticon: 1
  });
}
/**
 * 获取积分信息
 */


function getScore() {
  return (0, _vnRequest.default)(vipCgi, {
    name: 'get_cscore',
    type: 1,
    otype: 'xjson'
  });
}
/**
 * 获取用户头像框
 */


function getAvatarPendant() {
  return (0, _vnRequest.default)(avatarPendantCgi, {
    name: 'spp_VipActConf_V2',
    cmd: 2,
    posId: 59,
    platform: 107,
    otype: 'xjson'
  });
}