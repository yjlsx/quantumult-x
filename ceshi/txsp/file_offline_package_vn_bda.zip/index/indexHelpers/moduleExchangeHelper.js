"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.moduleExchange = moduleExchange;

var _index = require("/index/store/index");

var _moduleLoader = require("/index/store/moduleLoader");

var atom = _interopRequireWildcard(require("/index/util/atom"));

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = Object.defineProperty && Object.getOwnPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : {}; if (desc.get || desc.set) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } } newObj.default = obj; return newObj; } }

/**
 * 为了支持宇宙版不得不搞出来的复杂换一换逻辑
 * 需要在父组件计算平铺横图模块的步数和需要展示的数据
 * @param {object} param
 * @param {object} indexPage
 */
function moduleExchange(param, indexPage) {
  console.log('---moduleExchange---');
  var index = param[0].dataset.index;

  var exchangeComponent = _index.Store.__vn.data.query("listData[".concat(index, "].cells[0]"));

  console.log(JSON.stringify(exchangeComponent.shake));

  if (!exchangeComponent.shake.loadFinish) {
    try {
      (0, _moduleLoader.moduleLoadNext)({
        index: index,
        cmsData: exchangeComponent.cmsData
      }, loadNextFinish);
    } catch (e) {
      console.log(e);
    }
  } else {
    var step = exchangeComponent.shake.step;
    var maxStep = exchangeComponent.shake.maxStep;

    if (maxStep === 1) {
      atom.invoke('toast', {
        content: "\u6CA1\u6709\u66F4\u591A\u63A8\u8350\u5185\u5BB9\u5566"
      });
      return;
    }

    step = (step + 1) % maxStep;
    var listIndex = index - 1;

    var allList = _index.Store.__vn.data.query("listData[".concat(listIndex, "].allList"));

    var stepLength = _index.Store.__vn.data.query("listData[".concat(listIndex, "].cells.length"));

    _index.Store.__vn.data.update("listData[".concat(listIndex, "].cells"), allList.slice(step * stepLength, (step + 1) * stepLength));

    _index.Store.__vn.data.update("listData[".concat(index, "].cells[0].shake.step"), step); // this.reportFlag.list = reportListById('cidList', this.reportFlag.list)

  }
}

function loadNextFinish(isNotLast, index) {
  var listIndex = index - 1;

  var step = _index.Store.__vn.data.query("listData[".concat(index, "].cells[0].shake.step"));

  var originalListIndex = _index.Store.__vn.data.query("listData[".concat(index, "].cells[0].shake.listIndex"));

  var stepLength = _index.Store.__vn.data.query("listData[".concat(listIndex, "].cells.length"));

  var allList = _index.Store.__vn.data.query("listData[".concat(listIndex, "].allList"));

  if (isNotLast) {
    _index.Store.__vn.data.update("listData[".concat(index, "].cells[0].shake.step"), step + 1);

    _index.Store.__vn.data.update("listData[".concat(index, "].cells[0].shake.maxStep"), step + 2);

    _index.Store.__vn.data.update("listData[".concat(listIndex, "].cells"), allList.slice((step + 1) * stepLength, (step + 2) * stepLength)); // Store.__vn.data.update('step', step + 1)
    // _this.maxStep = step + 2

  } else {
    _index.Store.__vn.data.update("listData[".concat(index, "].cells[0].shake.loadFinish"), true);

    _index.Store.__vn.data.update("listData[".concat(index, "].cells[0].shake.step"), 0);

    _index.Store.__vn.data.update("listData[".concat(listIndex, "].cells"), allList.slice(0, stepLength));

    _index.Store.listData[originalListIndex]['loadFinish'] = true;

    if (_index.Store.__vn.data.query("listData[".concat(index, "].cells[0].shake.maxStep")) === 1) {
      atom.invoke('toast', {
        content: "\u6CA1\u6709\u66F4\u591A\u63A8\u8350\u5185\u5BB9\u5566"
      });
    } // Store.__vn.data.update('step', 0)

  } // 上报这里后期改VR来报吧，目前宇宙版的逻辑基本没法上报换一换
  // _this.reportFlag.list = reportListById('cidList', _this.reportFlag.list)


  console.log("---loadNextFinish---isNotLast:".concat(isNotLast, "---step:").concat(_index.Store.__vn.data.query("listData[".concat(index, "].cells[0].shake.step")), "---"));
}