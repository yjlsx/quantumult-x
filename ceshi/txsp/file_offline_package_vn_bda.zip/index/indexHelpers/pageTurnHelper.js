"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.loadNext = loadNext;

var _index = require("../store/index");

var _action = require("../store/action");

var _util = require("../util/util");

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

/**
   * 翻页函数
   */
function loadNext(_x) {
  return _loadNext.apply(this, arguments);
}
/**
 * 本页翻完
 */


function _loadNext() {
  _loadNext = _asyncToGenerator(
  /*#__PURE__*/
  regeneratorRuntime.mark(function _callee(indexPage) {
    var pageContext;
    return regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            if (!(!indexPage.data.loadNextLock || !_index.Store.useNewData)) {
              _context.next = 2;
              break;
            }

            return _context.abrupt("return");

          case 2:
            indexPage.data.loadNextLock = false;
            console.log("---loadNextFunc---".concat(indexPage.data.page));
            pageContext = _index.Store.channelData && _index.Store.channelData.data.pageContext;

            if (!(pageContext === 'page=-1')) {
              _context.next = 9;
              break;
            }

            indexPage.noMorePage();
            _context.next = 21;
            break;

          case 9:
            _context.prev = 9;
            _context.next = 12;
            return _action.storeAction.getChannelData({
              modNum: indexPage.data.modNum,
              pageContext: pageContext,
              channelId: _index.Store.channelId
            }, indexPage);

          case 12:
            indexPage.data.page++;
            console.log('---fanye---' + _index.Store.channelData.data.pageContext);
            loadNextFinish(indexPage);
            _context.next = 21;
            break;

          case 17:
            _context.prev = 17;
            _context.t0 = _context["catch"](9);
            console.log('---loadNextErr---' + (0, _util.stringifyError)(_context.t0));
            loadNextFinish(indexPage);

          case 21:
          case "end":
            return _context.stop();
        }
      }
    }, _callee, null, [[9, 17]]);
  }));
  return _loadNext.apply(this, arguments);
}

function loadNextFinish(indexPage) {
  if (_index.Store.channelData && _index.Store.channelData.data.pageContext === 'page=-1') {
    noMorePage(indexPage);
  } else {
    indexPage.data.loadNextLock = true;
    indexPage.dom.modList.setFooterRefreshing(false);
  }
}
/**
 * 整页翻完
 */


function noMorePage(indexPage) {
  console.log('---noMorePage---');
  indexPage.data.loadNextLock = false;
  indexPage.data.loadFinish = true;

  _index.Store.__vn.data.update('footerLottie', false);

  indexPage.dom.modList.setFooterRefreshingEnabled(false);
}