"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.init = init;

var _index = require("../store/index");

var _moduleDataConfig = require("../store/moduleDataConfig");

var _action = require("../store/action");

var _util = require("../util/util");

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

console.log("-------initHelper------".concat(_typeof(_index.Store.__vn))); // var getDomById = require('../util/commonWithVNState')(Store.__vn).getDomById

/**
 * 页面数据初始化逻辑
 * 调用获取频道数据action并执行列表初始化逻辑
 * @param {bool} needRefreshUser 用来判断是否需要强制刷新用户数据
 */

function init(_x, _x2) {
  return _init.apply(this, arguments);
}
/**
 * 列表初始化
 * 判断列表数据是否合理
 * 后续获取首屏无关的数据（下拉刷新配置等信息）
 * 并对列表的上拉刷新和下拉刷新逻辑做更新
 */


function _init() {
  _init = _asyncToGenerator(
  /*#__PURE__*/
  regeneratorRuntime.mark(function _callee(indexPage, needRefreshUser) {
    var initStatus;
    return regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.prev = 0;

            _action.storeAction.getAppConfig();

            indexPage.reportJceLoad('init');
            initStatus = _index.Store.__vn.data.query('initStatus');

            if (initStatus === -1) {
              _index.Store.__vn.data.update('initStatus', 0);
            }

            console.log("---init---needRefreshUser:".concat(needRefreshUser));
            styleInit(indexPage);
            indexPage.data.initDone = false;
            indexPage.data.firstReport = true;
            indexPage.data.loadFinish = false;
            indexPage.data.page = 0;

            if (!needRefreshUser) {
              _context.next = 14;
              break;
            }

            _context.next = 14;
            return _action.storeAction.refreshUserData();

          case 14:
            indexPage.data.loadNextLock = false;
            _index.Store.listCount = 0;
            _context.next = 18;
            return _action.storeAction.getChannelData({
              modNum: indexPage.data.modNum,
              channelId: _index.Store.channelId
            }, indexPage);

          case 18:
            listInit(indexPage);
            _context.next = 25;
            break;

          case 21:
            _context.prev = 21;
            _context.t0 = _context["catch"](0);
            console.log('---initerr---' + (0, _util.stringifyError)(_context.t0) + _index.Store.isLogin);
            listInit(indexPage);

          case 25:
          case "end":
            return _context.stop();
        }
      }
    }, _callee, null, [[0, 21]]);
  }));
  return _init.apply(this, arguments);
}

function listInit(indexPage) {
  indexPage.data.loadNextLock = true;

  _action.storeAction.getPromotion({
    platform: _index.Store.systemInfo.platform,
    version: _index.Store.appInfo.version
  });

  _action.storeAction.getPullRefreshData();

  if (!_index.Store.channelData || !_index.Store.channelData.data || !_index.Store.channelData.data.modList || _index.Store.channelData.data.modList.length <= 0) {
    console.log('----initDone channelDataErr----');

    _index.Store.__vn.data.update('initStatus', -1);
  } else {
    _index.Store.__vn.data.update('initStatus', 1);

    console.log('----initDone----' + Date.now());
    indexPage.data.hasScroll = false;
    indexPage.dom.modList = _index.Store.__vn.dom.getElementById('mod_list');
    indexPage.dom.modList.setHeaderRefreshingEnabled && indexPage.dom.modList.setHeaderRefreshingEnabled(true); // 如果没有请求报错 认为可以正常翻页

    if (!indexPage.data.requestErr) {
      indexPage.dom.modList.setFooterRefreshingEnabled && indexPage.dom.modList.setFooterRefreshingEnabled(true);

      _index.Store.__vn.data.update('footerLottie', true);
    }
  }

  indexPage.data.initDone = true;
}
/**
 * 宇宙版新增
 * 用于初始化uisze和颜色模式
 */


function styleInit(indexPage) {
  _index.Store.uiSize = _index.Store.__vn.data.query('vn.media.vn_ui_size_type');

  _index.Store.__vn.data.update('uiSize', _index.Store.uiSize);

  _index.Store.maxUiSize = QLVN.getMaxUISizeType();
  _index.Store.colorScheme = _index.Store.__vn.data.query("vn.media['prefers-color-scheme']");

  _index.Store.__vn.data.watch('vn.media.vn_ui_size_type', onUiSizeChange.bind(indexPage)); // atom.invoke('toast', { content: `size:${Store.uiSize}-maxSize:${Store.maxUiSize}` })


  console.log("size:".concat(_index.Store.uiSize, "-maxSize:").concat(_index.Store.maxUiSize)); // Store.__vn.data.watch("vn.media['prefers-color-scheme']", indexPage.onColorSchemeChange.bind(this))
  // 把左文右图模块信息存到Store和Store.__vn.data中

  _index.Store.leftPicNum = _moduleDataConfig.leftPicNum[_index.Store.uiSize] || 1;

  _index.Store.__vn.data.update('leftPicNum', _index.Store.leftPicNum);
}
/**
   * 宇宙版app内UI大小发生变化时触发
   * 需要重新处理出符合当前UI大小的数据
   * @param {object} param
   */


function onUiSizeChange(_x3) {
  return _onUiSizeChange.apply(this, arguments);
}

function _onUiSizeChange() {
  _onUiSizeChange = _asyncToGenerator(
  /*#__PURE__*/
  regeneratorRuntime.mark(function _callee2(param) {
    var newSize;
    return regeneratorRuntime.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            newSize = _index.Store.__vn.data.query('vn.media.vn_ui_size_type');
            console.log("--onUiSizeChange--newSize:".concat(newSize, "--oldSize:").concat(_index.Store.uiSize)); // app会触发两次uisizeChange事件，第一次的时候值未发生变化

            if (!(newSize === _index.Store.uiSize)) {
              _context2.next = 4;
              break;
            }

            return _context2.abrupt("return");

          case 4:
            _index.Store.uiSize = newSize;

            _index.Store.__vn.data.update('uiSize', _index.Store.uiSize); // atom.invoke('toast', { content: `onUiSizeChange-size:${Store.uiSize}-maxSize:${Store.maxUiSize}` })


            _action.storeAction.refreshAllChannelData();

          case 7:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2);
  }));
  return _onUiSizeChange.apply(this, arguments);
}