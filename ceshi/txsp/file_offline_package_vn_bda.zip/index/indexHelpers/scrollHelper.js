"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.listScroll = listScroll;
exports.scrollStateChange = scrollStateChange;
exports.itemAttach = itemAttach;
exports.itemDetach = itemDetach;
exports.itemLoad = itemLoad;

var _index = require("../store/index");

var _commonReport = require("../../util/commonReport");

var atom = _interopRequireWildcard(require("../util/atom"));

var _action = require("../store/action");

var _pageTurnHelper = require("./pageTurnHelper");

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = Object.defineProperty && Object.getOwnPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : {}; if (desc.get || desc.set) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } } newObj.default = obj; return newObj; } }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

var throttle = require('/lib/lodash-es').throttle;
/**
   * 计算函数，用于在滚动中判断是否需要展示挽留弹窗
   * @param {object} param
   * @param {object} indexPage
   */


var calculateShowDetain = throttle(
/*#__PURE__*/
function () {
  var _ref = _asyncToGenerator(
  /*#__PURE__*/
  regeneratorRuntime.mark(function _callee(param, indexPage) {
    return regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            if (!(!indexPage.data.hasShowDetainTip && indexPage.data.page > 6 && param.event.deltaY < 0 && !_index.Store.hasClick && indexPage.data.loadNextLock)) {
              _context.next = 4;
              break;
            }

            _context.next = 3;
            return _action.storeAction.getDetainTip();

          case 3:
            if (_index.Store.detainTip.info) {
              console.log("----showDetainTip----page:".concat(indexPage.data.page));
              indexPage.data.hasShowDetainTip = true;

              _index.Store.__vn.data.update('isShowDetain', true);

              (0, _commonReport.reportItem)({
                cmsdata: {
                  reportKey: _index.Store.detainTip.info.report_key,
                  reportParams: _index.Store.detainTip.info.report_param
                },
                reportType: {
                  event: _index.Store.reportEvent.posterExpose
                }
              });
              setTimeout(function () {
                _index.Store.__vn.data.update('isShowDetain', false);
              }, 10000);
            }

          case 4:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function (_x, _x2) {
    return _ref.apply(this, arguments);
  };
}(), 500, {
  leading: true,
  trailing: false
});
/**
   * list滚动事件
   * @param {object} param
   * @param {object} indexPage
   */

function listScroll(param, indexPage) {
  var scrollOffset = indexPage.dom.modList.getScrollOffset && indexPage.dom.modList.getScrollOffset();

  if (!indexPage.data.listScrollLock && scrollOffset > 1) {
    atom.invoke('pageScrollPosition', {
      targetheight: 375,
      scrolloffset: 375
    });
    indexPage.data.listScrollLock = true;
  } else if (indexPage.data.listScrollLock && scrollOffset <= 1) {
    atom.invoke('pageScrollPosition', {
      targetheight: 375,
      scrolloffset: 0
    });
    indexPage.data.listScrollLock = false;
  }

  calculateShowDetain(param, indexPage);
}
/**
   * 滚动状态发生变化
   * @param {object} param
   * @param {object} indexPage
   */


function scrollStateChange(param, indexPage) {
  indexPage.data.hasScroll = true;
  atom.invoke('pageScrollStatus', {
    status: param.event.newState
  }); // 空闲时 开始上报 检查需要更新预约状态的模块

  if (param.event.newState === 0) {
    indexPage.doReport();
    indexPage.checkAttention();
  }
}
/**
   * 元素上屏
   * @param {object} param
   * @param {object} indexPage
   */


function itemAttach(param, indexPage) {
  if (param.event.cell) {
    var dom = param.event.cell.getChildElements()[0];

    if (dom && dom.scrollToLeft) {
      dom.scrollToLeft();
    }

    if (dom && dom.attach) {
      dom.attach();
    }
  }
}
/**
   * 元素下屏
   * @param {object} param
   * @param {object} indexPage
   */


function itemDetach(param) {
  if (param.event.cell) {
    var dom = param.event.cell.getChildElements()[0];

    if (dom && dom.dettach) {
      dom.dettach();
    }
  }
}

function itemLoad(param, indexPage) {
  // 首屏上报
  if (indexPage.data.firstReport || indexPage.data.firstRealReport) {
    setTimeout(function () {
      indexPage.dom.modList = _index.Store.__vn.dom.getElementById('mod_list', true);

      _action.storeAction.getScreenSize(indexPage); // 首次 缓存


      if (!_index.Store.ScreenHeight) {
        indexPage.reportJceLoad('hasNoHeight');
      }

      if (indexPage.data.firstReport && !_index.Store.useNewData && _index.Store.ScreenHeight) {
        indexPage.data.firstReport = false;
        indexPage.data.firstReportTimeout = setTimeout(function () {
          console.log('---cacheReport---');
          indexPage.doReport('doReportFromCache');
        }, 1500);
      }

      if (indexPage.data.firstRealReport && _index.Store.useNewData && _index.Store.ScreenHeight) {
        indexPage.data.firstReport = false;
        indexPage.data.firstRealReport = false;
        console.log('---realReport---');
        indexPage.reportJceLoad('realReport');
        indexPage.reportFlag = [];
        indexPage.doReport('doReportFromDirect');

        try {
          indexPage.data.firstReportTimeout && window.clearTimeout(indexPage.data.firstReportTimeout);
        } catch (e) {
          indexPage.reportJceLoad('clearTimeoutErr');
        }
      }
    }, 500);
  }

  if (_index.Store.__vn.data.query('listData.length') - +param.event.section < 12 && indexPage.data.initDone) {
    console.log('---preLoad---');
    (0, _pageTurnHelper.loadNext)(indexPage);
  }
}