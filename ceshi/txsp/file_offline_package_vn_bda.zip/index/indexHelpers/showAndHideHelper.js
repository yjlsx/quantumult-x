"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.onShow = onShow;
exports.onHide = onHide;

var _index = require("../store/index");

var atom = _interopRequireWildcard(require("../util/atom"));

var _util = require("../util/util");

var _action = require("../store/action");

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = Object.defineProperty && Object.getOwnPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : {}; if (desc.get || desc.set) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } } newObj.default = obj; return newObj; } }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

/**
 * app前后台切换展示通知
 * @param {object} indexPage
 */
function onShow(_x) {
  return _onShow.apply(this, arguments);
}
/**
 * app前后台切换隐藏通知
 * @param {object} indexPage
 */


function _onShow() {
  _onShow = _asyncToGenerator(
  /*#__PURE__*/
  regeneratorRuntime.mark(function _callee(indexPage) {
    return regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            console.log('---onShow---');

            if (_index.Store.systemInfo) {
              _context.next = 10;
              break;
            }

            _context.prev = 2;
            _context.next = 5;
            return _action.storeAction.getSystemInfo();

          case 5:
            _context.next = 10;
            break;

          case 7:
            _context.prev = 7;
            _context.t0 = _context["catch"](2);
            console.log("onShowgetInfoErr" + (0, _util.stringifyError)(_context.t0));

          case 10:
            _index.Store.onShowTime = Date.now();
            atom.invoke('reportEvent', {
              eventID: _index.Store.reportEvent.pageExpose,
              eventParams: {
                page_id: "".concat(_index.Store.systemInfo && _index.Store.systemInfo.isIos ? 'QLHollywoodController_' : 'HomeActivityTab4_').concat(_index.Store.channelId)
              }
            });
            atom.invoke('reportEvent', {
              eventID: _index.Store.reportEvent.channelExpose,
              eventParams: {
                page_id: "ViptabVnShow_".concat(_index.Store.channelId),
                recommend_channel_id: _index.Store.channelId
              }
            });

            if (!indexPage.data.initDone) {
              _context.next = 19;
              break;
            }

            // 由于未知原因这里从未登录到登录的状态切换会触发itemload
            // 如果不先给翻页加锁 会导致请求错位
            indexPage.data.itemLoadLock = true;
            _context.next = 17;
            return _action.storeAction.refreshUserData();

          case 17:
            setTimeout(function () {
              updateFocusStatus(true, indexPage);
              indexPage.dom.modList.setHeaderRefreshing && indexPage.dom.modList.setHeaderRefreshing(false);

              _action.storeAction.getPullRefreshData();

              indexPage.checkAttention();
              indexPage.doReport('doReportFromOnshow');
            }, 0); // 800ms后恢复预加载逻辑

            setTimeout(function () {
              indexPage.data.itemLoadLock = false;
            }, 800);

          case 19:
          case "end":
            return _context.stop();
        }
      }
    }, _callee, null, [[2, 7]]);
  }));
  return _onShow.apply(this, arguments);
}

function onHide(indexPage) {
  console.log('---onHide---');
  indexPage && indexPage.dom.modList.setHeaderRefreshing && indexPage.dom.modList.setHeaderRefreshing(false);
  updateFocusStatus(false, indexPage);
  indexPage.reportFlag = [];
  _index.Store.systemInfo && atom.invoke('reportEvent', {
    eventID: _index.Store.reportEvent.pageStay,
    eventParams: {
      page_id: "".concat(_index.Store.systemInfo.isIos ? 'QLHollywoodController_' : 'HomeActivityTab4_').concat(_index.Store.channelId),
      duration: Date.now() - _index.Store.onShowTime
    }
  });
}
/**
 * 切换前后台需要处理焦点图模块的状态
 * @param {boolean} isShow
 * @param {*} indexPage
 */


function updateFocusStatus(isShow, indexPage) {
  var elements = indexPage.dom.modList.getVisibleChildElements && indexPage.dom.modList.getVisibleChildElements();
  elements && elements.forEach(function (item) {
    var dataset = item.getDataSet();

    if (dataset.name === 'focusModule') {
      var realDom = item.getChildElements()[0];
      isShow ? realDom.show() : realDom.hide();
    }
  });
}