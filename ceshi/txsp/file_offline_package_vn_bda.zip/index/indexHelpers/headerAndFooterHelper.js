"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.headerRefreshing = headerRefreshing;
exports.onHeaderStateChange = onHeaderStateChange;
exports.onFooterStateChange = onFooterStateChange;

var _index = require("../store/index");

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

/**
 * 下拉刷新事件触发
 * @param {Object} param
 * @param {Object} indexPage
 */
function headerRefreshing(_x, _x2) {
  return _headerRefreshing.apply(this, arguments);
}

function _headerRefreshing() {
  _headerRefreshing = _asyncToGenerator(
  /*#__PURE__*/
  regeneratorRuntime.mark(function _callee2(param, indexPage) {
    return regeneratorRuntime.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            console.log('--headerRefreshing---');
            setTimeout(
            /*#__PURE__*/
            _asyncToGenerator(
            /*#__PURE__*/
            regeneratorRuntime.mark(function _callee() {
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.prev = 0;

                      if (!((indexPage.data.loadNextLock || indexPage.data.loadFinish) && indexPage.data.initDone)) {
                        _context.next = 6;
                        break;
                      }

                      _context.next = 4;
                      return indexPage.init(true);

                    case 4:
                      _context.next = 8;
                      break;

                    case 6:
                      if (!indexPage.data.initDone) {
                        console.log('---initIng---');
                      }

                      if (!indexPage.data.loadNextLock) {
                        console.log('---loadNextIng---');
                      }

                    case 8:
                      _context.prev = 8;
                      setTimeout(function () {
                        moduleRefresh(indexPage);
                        param.target.setHeaderRefreshing(false);
                        indexPage.data.doPullRefresh = false;
                      }, 0);
                      return _context.finish(8);

                    case 11:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, null, [[0,, 8, 11]]);
            })), indexPage.data.doPullRefresh ? 1000 : 0);

          case 2:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2);
  }));
  return _headerRefreshing.apply(this, arguments);
}

function moduleRefresh(indexPage) {
  var elements = indexPage.dom.modList.getVisibleChildElements && indexPage.dom.modList.getVisibleChildElements();
  elements && elements.forEach(function (item) {
    var realDom = item.getChildElements()[0];
    realDom.refresh && realDom.refresh();
  });
}
/**
 * header状态变化事件
 * 主要用来控制lottie播放
 * @param {Object} params
 * @param {Object} indexPage
 */


function onHeaderStateChange(params, indexPage) {
  var getDomById = require('../util/commonWithVNState')(_index.Store.__vn).getDomById;

  var headerLottie = getDomById('headerLottie');

  switch (params.event.state) {
    case 0:
      // 空闲中
      indexPage.data.headerRefreshLock = false;
      break;

    case 1:
      indexPage.data.headerRefreshLock = true;
      indexPage.data.listScrollLock = false; // 拖拽中

      if (!_index.Store.pullRefreshData.pullImageViewUrl && !_index.Store.pullRefreshData.tipString) {
        headerLottie && headerLottie.setProperty('playstate', true);
      }

      break;

    case 2:
      // 松手
      break;

    case 3:
      // 刷新中
      break;

    case 4:
      // 刷新完成
      if (!_index.Store.pullRefreshData.pullImageViewUrl && !_index.Store.pullRefreshData.tipString) {
        headerLottie && headerLottie.setProperty('playstate', false);
      }

      break;
  }
}
/**
 * footer状态变化
 * 主要用来控制lottie播放
 * @param {Object} params
 */


function onFooterStateChange(params) {
  console.log('--onFooterStateChange---' + params.event.state);

  var getDomById = require('../util/commonWithVNState')(_index.Store.__vn).getDomById;

  var footerLottie = getDomById('footerLottie');

  switch (params.event.state) {
    case 0:
      footerLottie.setProperty('playstate', false);
      break;

    case 1:
      footerLottie.setProperty('playstate', true);
      break;

    case 2:
      footerLottie.setProperty('playstate', false);
      break;
  }
}