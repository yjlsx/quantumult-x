"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.doReport = doReport;

var _util = require("../util/util");

/**
 * 当前view的所有节点的曝光函数
 * @param {object} indexPage
 * @param {string} from 用来上报调用来源
 */
function doReport(indexPage, from) {
  console.log("---doReport---".concat(from));

  try {
    if (from) {
      indexPage.reportJceLoad(from);
    }

    var visibleDom = indexPage.dom.modList.getVisibleChildElements();
    var visibleIds = [];

    if (!visibleDom || !visibleDom.length) {
      indexPage.reportJceLoad('noVisibleDom');
    }

    visibleDom.forEach(function (item) {
      indexPage.reportJceLoad('visibleDom');
      var dataset = item.getDataSet();
      visibleIds.push(dataset.reportid); // console.log('----visibleDom----' + JSON.stringify(dataset) + `--${indexPage.reportFlag}`)

      var realDom = item.getChildElements()[0];

      if (indexPage.reportFlag.indexOf(dataset.reportid) < 0) {
        indexPage.reportJceLoad('visibleDomNewReport');
        realDom && realDom.report && realDom.report(true);
      } else {
        realDom && realDom.report && realDom.report(false);
      }
    });
    indexPage.reportFlag = visibleIds;
  } catch (e) {
    console.log("--reporterr--".concat((0, _util.stringifyError)(e)));
  }
}